<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_comment_data_1`;");
E_C("CREATE TABLE `lt_comment_data_1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '评论ID',
  `commentid` char(30) NOT NULL DEFAULT '' COMMENT '评论ID号',
  `siteid` smallint(5) NOT NULL DEFAULT '0' COMMENT '站点ID',
  `userid` int(10) unsigned DEFAULT '0' COMMENT '用户ID',
  `username` varchar(20) DEFAULT NULL COMMENT '用户名',
  `creat_at` int(10) DEFAULT NULL COMMENT '发布时间',
  `ip` varchar(15) DEFAULT NULL COMMENT '用户IP地址',
  `status` tinyint(1) DEFAULT '0' COMMENT '评论状态{0:未审核,-1:未通过审核,1:通过审核}',
  `content` text COMMENT '评论内容',
  `direction` tinyint(1) DEFAULT '0' COMMENT '评论方向{0:无方向,1:正文,2:反方,3:中立}',
  `support` mediumint(8) unsigned DEFAULT '0' COMMENT '支持数',
  `reply` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否为回复',
  PRIMARY KEY (`id`),
  KEY `commentid` (`commentid`),
  KEY `direction` (`direction`),
  KEY `siteid` (`siteid`),
  KEY `support` (`support`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `lt_comment_data_1` values('1','content_9-1-1','1','0','中国粉体网网友','1364867491','127.0.0.1','0','12313','1','0','0');");
E_D("replace into `lt_comment_data_1` values('2','content_9-64-1','1','8','yyx','1365323883','202.204.107.4','0','挺好','1','0','0');");
E_D("replace into `lt_comment_data_1` values('3','content_9-64-1','1','0','中国粉体技术网网友','1365584065','114.250.207.92','0','好','1','0','0');");
E_D("replace into `lt_comment_data_1` values('4','content_9-63-1','1','0','中国粉体技术网网友','1365584126','114.250.207.92','0','不错','1','0','0');");
E_D("replace into `lt_comment_data_1` values('5','content_52-208-1','1','18','111','1365993520','111.193.244.232','0','好','0','0','0');");

require("../../inc/footer.php");
?>