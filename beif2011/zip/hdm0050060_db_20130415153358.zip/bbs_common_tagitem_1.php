<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_common_tagitem`;");
E_C("CREATE TABLE `bbs_common_tagitem` (
  `tagid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `itemid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `idtype` char(10) NOT NULL DEFAULT '',
  UNIQUE KEY `item` (`tagid`,`itemid`,`idtype`),
  KEY `idtype` (`idtype`,`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `bbs_common_tagitem` values('1','3','tid');");
E_D("replace into `bbs_common_tagitem` values('1','4','tid');");
E_D("replace into `bbs_common_tagitem` values('1','5','tid');");
E_D("replace into `bbs_common_tagitem` values('2','3','tid');");
E_D("replace into `bbs_common_tagitem` values('3','2','tid');");
E_D("replace into `bbs_common_tagitem` values('4','2','tid');");
E_D("replace into `bbs_common_tagitem` values('5','2','tid');");
E_D("replace into `bbs_common_tagitem` values('6','4','tid');");
E_D("replace into `bbs_common_tagitem` values('7','4','tid');");
E_D("replace into `bbs_common_tagitem` values('8','4','tid');");
E_D("replace into `bbs_common_tagitem` values('9','5','tid');");
E_D("replace into `bbs_common_tagitem` values('10','5','tid');");
E_D("replace into `bbs_common_tagitem` values('11','5','tid');");
E_D("replace into `bbs_common_tagitem` values('12','5','tid');");

require("../../inc/footer.php");
?>