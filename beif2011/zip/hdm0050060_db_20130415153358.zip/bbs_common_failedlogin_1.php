<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_common_failedlogin`;");
E_C("CREATE TABLE `bbs_common_failedlogin` (
  `ip` char(15) NOT NULL DEFAULT '',
  `username` char(32) NOT NULL DEFAULT '',
  `count` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lastupdate` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ip`,`username`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `bbs_common_failedlogin` values('222.129.55.71','','0','1365319307');");
E_D("replace into `bbs_common_failedlogin` values('222.129.39.108','','0','1364954535');");
E_D("replace into `bbs_common_failedlogin` values('222.129.36.111','','1','1365668237');");
E_D("replace into `bbs_common_failedlogin` values('61.149.192.145','','0','1365749776');");

require("../../inc/footer.php");
?>