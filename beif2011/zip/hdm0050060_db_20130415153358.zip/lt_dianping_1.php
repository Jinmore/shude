<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_dianping`;");
E_C("CREATE TABLE `lt_dianping` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `dianpingid` char(40) NOT NULL,
  `dianping_typeid` int(3) NOT NULL,
  `siteid` smallint(8) NOT NULL,
  `dianping_nums` int(10) NOT NULL,
  `data1` tinyint(1) DEFAULT NULL,
  `data2` tinyint(1) DEFAULT NULL,
  `data3` tinyint(1) DEFAULT NULL,
  `data4` tinyint(1) DEFAULT NULL,
  `data5` tinyint(1) DEFAULT NULL,
  `data6` tinyint(1) DEFAULT NULL,
  `addtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");

require("../../inc/footer.php");
?>