<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_comment`;");
E_C("CREATE TABLE `lt_comment` (
  `commentid` char(30) NOT NULL,
  `siteid` smallint(5) NOT NULL DEFAULT '0',
  `title` char(255) NOT NULL,
  `url` char(255) NOT NULL,
  `total` int(8) unsigned DEFAULT '0',
  `square` mediumint(8) unsigned DEFAULT '0',
  `anti` mediumint(8) unsigned DEFAULT '0',
  `neutral` mediumint(8) unsigned DEFAULT '0',
  `display_type` tinyint(1) DEFAULT '0',
  `tableid` mediumint(8) unsigned DEFAULT '0',
  `lastupdate` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`commentid`),
  KEY `lastupdate` (`lastupdate`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lt_comment` values('content_9-1-1','1','第十三届全国非金属矿加工利用技术交流会第一轮（征文）','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=9&id=1','0','0','0','0','1','1','1364867491');");
E_D("replace into `lt_comment` values('content_9-64-1','1','内蒙古超牌建材科技有限公司年产6万吨煅烧高岭土项目紧张建设中','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=9&id=64','0','0','0','0','1','1','1365584065');");
E_D("replace into `lt_comment` values('content_9-63-1','1','丹东百特举行2012年粒度测试技术（广州）交流会','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=9&id=63','0','0','0','0','1','1','1365584126');");
E_D("replace into `lt_comment` values('content_52-208-1','1','广西平桂管理区重质碳酸钙粉体生产概况','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=52&id=208','0','0','0','0','0','1','1365993520');");

require("../../inc/footer.php");
?>