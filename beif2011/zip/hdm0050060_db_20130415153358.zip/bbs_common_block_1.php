<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_common_block`;");
E_C("CREATE TABLE `bbs_common_block` (
  `bid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `blockclass` varchar(255) NOT NULL DEFAULT '0',
  `blocktype` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `title` text NOT NULL,
  `classname` varchar(255) NOT NULL DEFAULT '',
  `summary` text NOT NULL,
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(255) NOT NULL DEFAULT '',
  `styleid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `blockstyle` text NOT NULL,
  `picwidth` smallint(6) unsigned NOT NULL DEFAULT '0',
  `picheight` smallint(6) unsigned NOT NULL DEFAULT '0',
  `target` varchar(255) NOT NULL DEFAULT '',
  `dateformat` varchar(255) NOT NULL DEFAULT '',
  `dateuformat` tinyint(1) NOT NULL DEFAULT '0',
  `script` varchar(255) NOT NULL DEFAULT '',
  `param` text NOT NULL,
  `shownum` smallint(6) unsigned NOT NULL DEFAULT '0',
  `cachetime` int(10) NOT NULL DEFAULT '0',
  `cachetimerange` char(5) NOT NULL DEFAULT '',
  `punctualupdate` tinyint(1) NOT NULL DEFAULT '0',
  `hidedisplay` tinyint(1) NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `notinherited` tinyint(1) NOT NULL DEFAULT '0',
  `isblank` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`bid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `bbs_common_block` values('1','group_thread','0','','','','','1','wz010','0','Array','339','215','blank','Y-m-d','0','groupthread','a:8:{s:5:\"gtids\";a:1:{i:0;s:1:\"0\";}s:12:\"rewardstatus\";s:1:\"0\";s:11:\"titlelength\";s:2:\"40\";s:13:\"summarylength\";s:2:\"80\";s:8:\"startrow\";s:1:\"0\";s:5:\"items\";s:1:\"4\";s:7:\"special\";a:1:{i:0;s:1:\"0\";}s:11:\"picrequired\";s:1:\"1\";}','4','0','','0','0','0','0','0');");
E_D("replace into `bbs_common_block` values('2','group_thread','0','','','','','1','wz010','24','','0','0','blank','Y-m-d','0','groupthreadspecial','a:6:{s:5:\"gtids\";a:1:{i:0;s:1:\"0\";}s:12:\"rewardstatus\";s:1:\"0\";s:11:\"picrequired\";s:1:\"0\";s:11:\"titlelength\";s:2:\"40\";s:13:\"summarylength\";s:2:\"80\";s:5:\"items\";s:2:\"10\";}','10','3600','','0','0','1365320181','0','0');");
E_D("replace into `bbs_common_block` values('3','forum_thread','1','网站调用','','','','1','wz010','112','','0','0','blank','Y-m-d','0','thread','a:19:{s:4:\"tids\";s:0:\"\";s:4:\"uids\";s:0:\"\";s:7:\"keyword\";s:0:\"\";s:10:\"tagkeyword\";s:0:\"\";s:4:\"fids\";a:1:{i:0;s:1:\"0\";}s:7:\"typeids\";s:0:\"\";s:7:\"sortids\";a:1:{i:0;s:1:\"0\";}s:9:\"recommend\";s:1:\"0\";s:7:\"viewmod\";s:1:\"0\";s:12:\"rewardstatus\";s:1:\"0\";s:11:\"picrequired\";s:1:\"0\";s:7:\"orderby\";s:8:\"lastpost\";s:12:\"postdateline\";s:1:\"0\";s:8:\"lastpost\";s:1:\"0\";s:9:\"highlight\";s:1:\"0\";s:11:\"titlelength\";s:2:\"40\";s:13:\"summarylength\";s:2:\"80\";s:8:\"startrow\";s:1:\"0\";s:5:\"items\";i:6;}','6','3600','','0','0','1366009462','0','0');");
E_D("replace into `bbs_common_block` values('4','forum_thread','1','新闻频道页调用','','','','1','wz010','113','','0','0','blank','Y-m-d','0','thread','a:19:{s:4:\"tids\";s:0:\"\";s:4:\"uids\";s:0:\"\";s:7:\"keyword\";s:0:\"\";s:10:\"tagkeyword\";s:0:\"\";s:4:\"fids\";a:1:{i:0;s:1:\"0\";}s:7:\"typeids\";s:0:\"\";s:7:\"sortids\";a:1:{i:0;s:1:\"0\";}s:9:\"recommend\";s:1:\"0\";s:7:\"viewmod\";s:1:\"0\";s:12:\"rewardstatus\";s:1:\"0\";s:11:\"picrequired\";s:1:\"0\";s:7:\"orderby\";s:8:\"lastpost\";s:12:\"postdateline\";s:1:\"0\";s:8:\"lastpost\";s:1:\"0\";s:9:\"highlight\";s:1:\"0\";s:11:\"titlelength\";s:2:\"26\";s:13:\"summarylength\";s:2:\"80\";s:8:\"startrow\";s:1:\"0\";s:5:\"items\";i:7;}','7','3600','','0','0','1366005895','0','0');");
E_D("replace into `bbs_common_block` values('5','forum_thread','1','栏目页调用','','','','1','wz010','112','','0','0','blank','Y-m-d','0','thread','a:19:{s:4:\"tids\";s:0:\"\";s:4:\"uids\";s:0:\"\";s:7:\"keyword\";s:0:\"\";s:10:\"tagkeyword\";s:0:\"\";s:4:\"fids\";a:1:{i:0;s:1:\"0\";}s:7:\"typeids\";s:0:\"\";s:7:\"sortids\";a:1:{i:0;s:1:\"0\";}s:9:\"recommend\";s:1:\"0\";s:7:\"viewmod\";s:1:\"0\";s:12:\"rewardstatus\";s:1:\"0\";s:11:\"picrequired\";s:1:\"0\";s:7:\"orderby\";s:8:\"lastpost\";s:12:\"postdateline\";s:1:\"0\";s:8:\"lastpost\";s:1:\"0\";s:9:\"highlight\";s:1:\"0\";s:11:\"titlelength\";s:2:\"50\";s:13:\"summarylength\";s:2:\"80\";s:8:\"startrow\";s:1:\"0\";s:5:\"items\";i:50;}','50','3600','','0','0','1366007201','0','0');");

require("../../inc/footer.php");
?>