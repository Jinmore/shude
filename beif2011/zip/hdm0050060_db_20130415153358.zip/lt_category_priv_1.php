<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_category_priv`;");
E_C("CREATE TABLE `lt_category_priv` (
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `roleid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `is_admin` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `action` char(30) NOT NULL,
  KEY `catid` (`catid`,`roleid`,`is_admin`,`action`),
  KEY `siteid` (`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lt_category_priv` values('37','1','6','0','add');");
E_D("replace into `lt_category_priv` values('37','1','4','0','add');");
E_D("replace into `lt_category_priv` values('37','1','2','0','add');");
E_D("replace into `lt_category_priv` values('37','1','5','0','add');");
E_D("replace into `lt_category_priv` values('27','1','2','0','add');");
E_D("replace into `lt_category_priv` values('27','1','5','0','visit');");
E_D("replace into `lt_category_priv` values('27','1','2','0','visit');");
E_D("replace into `lt_category_priv` values('27','1','5','0','add');");
E_D("replace into `lt_category_priv` values('38','1','5','0','add');");
E_D("replace into `lt_category_priv` values('38','1','2','0','add');");
E_D("replace into `lt_category_priv` values('38','1','4','0','add');");
E_D("replace into `lt_category_priv` values('38','1','6','0','add');");
E_D("replace into `lt_category_priv` values('20','1','5','0','add');");
E_D("replace into `lt_category_priv` values('20','1','2','0','add');");
E_D("replace into `lt_category_priv` values('20','1','4','0','add');");
E_D("replace into `lt_category_priv` values('20','1','6','0','add');");
E_D("replace into `lt_category_priv` values('58','1','2','0','add');");
E_D("replace into `lt_category_priv` values('58','1','6','0','add');");
E_D("replace into `lt_category_priv` values('58','1','4','0','add');");
E_D("replace into `lt_category_priv` values('58','1','5','0','add');");
E_D("replace into `lt_category_priv` values('59','1','2','0','add');");
E_D("replace into `lt_category_priv` values('59','1','6','0','add');");
E_D("replace into `lt_category_priv` values('59','1','4','0','add');");
E_D("replace into `lt_category_priv` values('59','1','5','0','add');");
E_D("replace into `lt_category_priv` values('60','1','2','0','add');");
E_D("replace into `lt_category_priv` values('60','1','6','0','add');");
E_D("replace into `lt_category_priv` values('60','1','4','0','add');");
E_D("replace into `lt_category_priv` values('60','1','5','0','add');");
E_D("replace into `lt_category_priv` values('61','1','2','0','add');");
E_D("replace into `lt_category_priv` values('61','1','6','0','add');");
E_D("replace into `lt_category_priv` values('61','1','4','0','add');");
E_D("replace into `lt_category_priv` values('61','1','5','0','add');");
E_D("replace into `lt_category_priv` values('62','1','2','0','add');");
E_D("replace into `lt_category_priv` values('62','1','6','0','add');");
E_D("replace into `lt_category_priv` values('62','1','4','0','add');");
E_D("replace into `lt_category_priv` values('62','1','5','0','add');");
E_D("replace into `lt_category_priv` values('63','1','2','0','add');");
E_D("replace into `lt_category_priv` values('63','1','6','0','add');");
E_D("replace into `lt_category_priv` values('63','1','4','0','add');");
E_D("replace into `lt_category_priv` values('63','1','5','0','add');");
E_D("replace into `lt_category_priv` values('64','1','2','0','add');");
E_D("replace into `lt_category_priv` values('64','1','6','0','add');");
E_D("replace into `lt_category_priv` values('64','1','4','0','add');");
E_D("replace into `lt_category_priv` values('64','1','5','0','add');");
E_D("replace into `lt_category_priv` values('65','1','2','0','add');");
E_D("replace into `lt_category_priv` values('65','1','6','0','add');");
E_D("replace into `lt_category_priv` values('65','1','4','0','add');");
E_D("replace into `lt_category_priv` values('65','1','5','0','add');");
E_D("replace into `lt_category_priv` values('66','1','2','0','add');");
E_D("replace into `lt_category_priv` values('66','1','6','0','add');");
E_D("replace into `lt_category_priv` values('66','1','4','0','add');");
E_D("replace into `lt_category_priv` values('66','1','5','0','add');");
E_D("replace into `lt_category_priv` values('27','1','4','0','visit');");
E_D("replace into `lt_category_priv` values('27','1','4','0','add');");
E_D("replace into `lt_category_priv` values('27','1','6','0','visit');");
E_D("replace into `lt_category_priv` values('27','1','6','0','add');");
E_D("replace into `lt_category_priv` values('21','1','6','0','add');");
E_D("replace into `lt_category_priv` values('21','1','5','0','add');");
E_D("replace into `lt_category_priv` values('21','1','4','0','add');");
E_D("replace into `lt_category_priv` values('21','1','2','0','add');");
E_D("replace into `lt_category_priv` values('49','1','2','0','add');");
E_D("replace into `lt_category_priv` values('49','1','6','0','add');");
E_D("replace into `lt_category_priv` values('49','1','4','0','add');");
E_D("replace into `lt_category_priv` values('49','1','5','0','add');");
E_D("replace into `lt_category_priv` values('50','1','2','0','add');");
E_D("replace into `lt_category_priv` values('50','1','6','0','add');");
E_D("replace into `lt_category_priv` values('50','1','4','0','add');");
E_D("replace into `lt_category_priv` values('50','1','5','0','add');");
E_D("replace into `lt_category_priv` values('51','1','2','0','add');");
E_D("replace into `lt_category_priv` values('51','1','6','0','add');");
E_D("replace into `lt_category_priv` values('51','1','4','0','add');");
E_D("replace into `lt_category_priv` values('51','1','5','0','add');");
E_D("replace into `lt_category_priv` values('52','1','2','0','add');");
E_D("replace into `lt_category_priv` values('52','1','6','0','add');");
E_D("replace into `lt_category_priv` values('52','1','4','0','add');");
E_D("replace into `lt_category_priv` values('52','1','5','0','add');");
E_D("replace into `lt_category_priv` values('53','1','2','0','add');");
E_D("replace into `lt_category_priv` values('53','1','6','0','add');");
E_D("replace into `lt_category_priv` values('53','1','4','0','add');");
E_D("replace into `lt_category_priv` values('53','1','5','0','add');");
E_D("replace into `lt_category_priv` values('54','1','2','0','add');");
E_D("replace into `lt_category_priv` values('54','1','6','0','add');");
E_D("replace into `lt_category_priv` values('54','1','4','0','add');");
E_D("replace into `lt_category_priv` values('54','1','5','0','add');");
E_D("replace into `lt_category_priv` values('55','1','2','0','add');");
E_D("replace into `lt_category_priv` values('55','1','6','0','add');");
E_D("replace into `lt_category_priv` values('55','1','4','0','add');");
E_D("replace into `lt_category_priv` values('55','1','5','0','add');");
E_D("replace into `lt_category_priv` values('56','1','2','0','add');");
E_D("replace into `lt_category_priv` values('56','1','6','0','add');");
E_D("replace into `lt_category_priv` values('56','1','4','0','add');");
E_D("replace into `lt_category_priv` values('56','1','5','0','add');");
E_D("replace into `lt_category_priv` values('57','1','2','0','add');");
E_D("replace into `lt_category_priv` values('57','1','6','0','add');");
E_D("replace into `lt_category_priv` values('57','1','4','0','add');");
E_D("replace into `lt_category_priv` values('57','1','5','0','add');");

require("../../inc/footer.php");
?>