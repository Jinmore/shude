<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_poster_space`;");
E_C("CREATE TABLE `lt_poster_space` (
  `spaceid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` char(50) NOT NULL,
  `type` char(30) NOT NULL,
  `path` char(40) NOT NULL,
  `width` smallint(4) unsigned NOT NULL DEFAULT '0',
  `height` smallint(4) unsigned NOT NULL DEFAULT '0',
  `setting` char(100) NOT NULL,
  `description` char(100) NOT NULL,
  `items` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`spaceid`),
  KEY `disabled` (`disabled`,`siteid`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8");
E_D("replace into `lt_poster_space` values('20','1','横幅广告二','banner','poster_js/20.js','275','60','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅广告二','1','0');");
E_D("replace into `lt_poster_space` values('19','1','横幅广告一','banner','poster_js/19.js','200','60','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅广告一','1','0');");
E_D("replace into `lt_poster_space` values('18','1','协会右侧广告三','banner','poster_js/18.js','210','65','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','协会右侧广告三','1','0');");
E_D("replace into `lt_poster_space` values('17','1','协会右侧广告二','banner','poster_js/17.js','210','65','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','协会右侧广告二','1','0');");
E_D("replace into `lt_poster_space` values('16','1','协会右侧广告一','banner','poster_js/16.js','210','65','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','协会右侧广告一','1','0');");
E_D("replace into `lt_poster_space` values('15','1','导航位置图片广告三','banner','poster_js/15.js','165','75','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','导航位置图片广告第三个','1','0');");
E_D("replace into `lt_poster_space` values('14','1','导航位置图片广告二','banner','poster_js/14.js','556','75','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','导航位置图片广告第二个','1','0');");
E_D("replace into `lt_poster_space` values('13','1','导航位置图片广告一','banner','poster_js/13.js','165','75','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','导航位置图片广告第一个','1','0');");
E_D("replace into `lt_poster_space` values('12','1','导航位置文字广告二','text','poster_js/12.js','0','0','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','导航位置文字广告第二行','0','0');");
E_D("replace into `lt_poster_space` values('11','1','导航位置文字广告一','text','poster_js/11.js','0','0','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','导航位置文字广告第一行','10','0');");
E_D("replace into `lt_poster_space` values('21','1','横幅广告三','banner','poster_js/21.js','275','60','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅广告三','1','0');");
E_D("replace into `lt_poster_space` values('22','1','横幅广告四','banner','poster_js/22.js','210','60','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅广告四','1','0');");
E_D("replace into `lt_poster_space` values('23','1','大横幅广告位一','banner','poster_js/23.js','980','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','大横幅广告位一','1','0');");
E_D("replace into `lt_poster_space` values('24','1','横幅2广告一','banner','poster_js/24.js','200','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅2广告一','1','0');");
E_D("replace into `lt_poster_space` values('25','1','横幅2广告二','banner','poster_js/25.js','556','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅2广告二','1','0');");
E_D("replace into `lt_poster_space` values('26','1','横幅2广告三','banner','poster_js/26.js','210','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅2广告三','1','0');");
E_D("replace into `lt_poster_space` values('27','1','市场左侧广告一','banner','poster_js/27.js','200','63','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场左侧广告一','1','0');");
E_D("replace into `lt_poster_space` values('28','1','市场左侧广告二','banner','poster_js/28.js','200','66','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场左侧广告二','1','0');");
E_D("replace into `lt_poster_space` values('29','1','市场左侧广告三','banner','poster_js/29.js','200','63','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场左侧广告三','1','0');");
E_D("replace into `lt_poster_space` values('30','1','求购右侧广告一','banner','poster_js/30.js','210','64','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','求购右侧广告一','1','0');");
E_D("replace into `lt_poster_space` values('31','1','求购右侧广告二','banner','poster_js/31.js','210','63','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','求购右侧广告二','1','0');");
E_D("replace into `lt_poster_space` values('32','1','求购右侧广告三','banner','poster_js/32.js','210','64','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','求购右侧广告三','1','0');");
E_D("replace into `lt_poster_space` values('33','1','大横幅广告位二','banner','poster_js/33.js','980','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','大横幅广告位二','1','0');");
E_D("replace into `lt_poster_space` values('34','1','横幅3广告一','banner','poster_js/34.js','200','65','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅3广告一','1','0');");
E_D("replace into `lt_poster_space` values('35','1','横幅3广告二','banner','poster_js/35.js','556','65','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅3广告二','1','0');");
E_D("replace into `lt_poster_space` values('36','1','横幅3广告三','banner','poster_js/36.js','210','65','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','横幅3广告三','1','0');");
E_D("replace into `lt_poster_space` values('37','1','频道页横幅广告一','banner','poster_js/37.js','980','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','频道页横幅广告一','1','0');");
E_D("replace into `lt_poster_space` values('38','1','技术频道专家下侧广告','banner','poster_js/38.js','210','60','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','技术频道专家下侧广告','1','0');");
E_D("replace into `lt_poster_space` values('39','1','技术频道页横幅广告二','banner','poster_js/39.js','980','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','技术频道页横幅广告二','1','0');");
E_D("replace into `lt_poster_space` values('40','1','技术频道页横幅3广告一','banner','poster_js/40.js','200','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','技术频道页横幅3广告一','1','0');");
E_D("replace into `lt_poster_space` values('41','1','技术频道页横幅3广告二','banner','poster_js/41.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','技术频道页横幅3广告二','1','0');");
E_D("replace into `lt_poster_space` values('42','1','技术频道页横幅3广告三','banner','poster_js/42.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','技术频道页横幅3广告三','1','0');");
E_D("replace into `lt_poster_space` values('43','1','技术频道页横幅3广告四','banner','poster_js/43.js','210','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','技术频道页横幅3广告四','1','0');");
E_D("replace into `lt_poster_space` values('44','1','栏目页右侧广告一','banner','poster_js/44.js','210','64','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','栏目页右侧广告一','1','0');");
E_D("replace into `lt_poster_space` values('45','1','栏目页右侧广告二','banner','poster_js/45.js','210','64','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','栏目页右侧广告二','1','0');");
E_D("replace into `lt_poster_space` values('46','1','新闻模板页横幅广告一','banner','poster_js/46.js','486','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','新闻模板页横幅广告一','1','0');");
E_D("replace into `lt_poster_space` values('47','1','新闻模板页横幅广告二','banner','poster_js/47.js','486','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','新闻模板页横幅广告二','1','0');");
E_D("replace into `lt_poster_space` values('48','1','粉体频道页专利下侧广告','banner','poster_js/48.js','210','72','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','粉体频道页专利下侧广告','1','0');");
E_D("replace into `lt_poster_space` values('49','1','粉体频道页横幅广告一','banner','poster_js/49.js','486','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','粉体频道页横幅广告一','1','0');");
E_D("replace into `lt_poster_space` values('50','1','粉体频道页横幅广告二','banner','poster_js/50.js','486','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','粉体频道页横幅广告二','1','0');");
E_D("replace into `lt_poster_space` values('51','1','粉体频道页横幅2广告一','banner','poster_js/51.js','200','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','粉体频道页横幅2广告一','1','0');");
E_D("replace into `lt_poster_space` values('52','1','粉体频道页横幅2广告二','banner','poster_js/52.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','粉体频道页横幅2广告二','1','0');");
E_D("replace into `lt_poster_space` values('53','1','粉体频道页横幅2广告三','banner','poster_js/53.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','粉体频道页横幅2广告三','1','0');");
E_D("replace into `lt_poster_space` values('54','1','粉体频道页横幅2广告四','banner','poster_js/54.js','210','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','粉体频道页横幅2广告四','1','0');");
E_D("replace into `lt_poster_space` values('55','1','新闻模板页横幅2广告一','banner','poster_js/55.js','200','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','新闻模板页横幅2广告一','1','0');");
E_D("replace into `lt_poster_space` values('56','1','新闻模板页横幅2广告二','banner','poster_js/56.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','新闻模板页横幅2广告二','1','0');");
E_D("replace into `lt_poster_space` values('57','1','新闻模板页横幅2广告三','banner','poster_js/57.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','新闻模板页横幅2广告三','1','0');");
E_D("replace into `lt_poster_space` values('58','1','新闻模板页横幅2广告四','banner','poster_js/58.js','210','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','新闻模板页横幅2广告四','1','0');");
E_D("replace into `lt_poster_space` values('59','1','市场频道页广告一','banner','poster_js/59.js','285','94','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场频道页广告一','1','0');");
E_D("replace into `lt_poster_space` values('60','1','市场频道页广告二','banner','poster_js/60.js','772','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场频道页广告二','1','0');");
E_D("replace into `lt_poster_space` values('61','1','市场频道页横幅广告一','banner','poster_js/61.js','200','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场频道页横幅广告一','1','0');");
E_D("replace into `lt_poster_space` values('62','1','市场频道页横幅广告二','banner','poster_js/62.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场频道页横幅广告二','1','0');");
E_D("replace into `lt_poster_space` values('63','1','市场频道页横幅广告三','banner','poster_js/63.js','275','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场频道页横幅广告三','1','0');");
E_D("replace into `lt_poster_space` values('64','1','市场频道页横幅广告四','banner','poster_js/64.js','210','70','array (\n  ''paddleft'' => '''',\n  ''paddtop'' => '''',\n)','市场频道页横幅广告四','1','0');");
E_D("replace into `lt_poster_space` values('65','1','对联广告一','couplet','poster_js/65.js','100','250','array (\n  ''paddleft'' => ''10'',\n  ''paddtop'' => ''100'',\n)','对联广告一','1','0');");
E_D("replace into `lt_poster_space` values('66','1','对联广告二','couplet','poster_js/66.js','100','250','array (\n  ''paddleft'' => ''10'',\n  ''paddtop'' => ''400'',\n)','对联广告二','1','0');");

require("../../inc/footer.php");
?>