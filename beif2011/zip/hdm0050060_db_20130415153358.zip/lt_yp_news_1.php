<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_yp_news`;");
E_C("CREATE TABLE `lt_yp_news` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` varchar(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` char(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `elite` tinyint(3) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8");
E_D("replace into `lt_yp_news` values('3','92','0','国家纳米中心提出高吸光性富勒烯材料设计新思路','','','国家 纳米 中心','国家纳米中心提出高吸光性富勒烯材料设计新思路','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=3','0','99','0','2','qaz123','1364375104','1364375104','0');");
E_D("replace into `lt_yp_news` values('2','92','0','内蒙古超牌建材科技有限公司年产6万吨煅烧高岭土项目紧张','','','内蒙古 建材 科技','内蒙古超牌建材科技有限公司年产6万吨煅烧高岭土项目紧张','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=com_index&a=show&modelid=13&catid=92&id=2&userid=1&pag','0','99','0','1','susu','1364361493','1364361493','1');");
E_D("replace into `lt_yp_news` values('5','92','0','石墨企业掀起深加工投资热 2012-03-26新材料“十二五”规划重','','','石墨 企业 掀起','石墨企业掀起深加工投资热 2012-03-26新材料“十二五”规划重点产品之粉体材料','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=5','0','99','0','2','qaz123','1364375136','1364375136','0');");
E_D("replace into `lt_yp_news` values('4','93','0','资料下载','','','资料下载','资料下载','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=93&id=4','0','99','0','2','qaz123','1364371707','1364371707','0');");
E_D("replace into `lt_yp_news` values('6','92','0','第十三届全国非金属矿加工利用技术交流会第一轮（征文）','','','第十三届 全国 非金属','第十三届全国非金属矿加工利用技术交流会第一轮（征文）通知','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=6','0','99','0','2','qaz123','1364375173','1364375173','0');");
E_D("replace into `lt_yp_news` values('7','92','0','水净化取得重大进展 纳米技术去除水中微污染物','','','净化 取得 重大','水净化取得重大进展 纳米技术去除水中微污染物','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=7','0','99','0','2','qaz123','1364375188','1364375188','0');");
E_D("replace into `lt_yp_news` values('8','92','0','丹东百特举行2012年粒度测试技术（广州）交流会','','','丹东 百特 举行','丹东百特举行2012年粒度测试技术（广州）交流会','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=8','0','99','0','2','qaz123','1364375207','1364375207','0');");
E_D("replace into `lt_yp_news` values('9','92','0','内蒙古超牌建材科技有限公司年产6万吨煅烧高岭土项目紧张','','','内蒙古 建材 科技','内蒙古超牌建材科技有限公司年产6万吨煅烧高岭土项目紧张','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=9','0','99','0','2','qaz123','1364375223','1364375223','0');");
E_D("replace into `lt_yp_news` values('10','102','0','内蒙古超牌建材科技有限公司','','','内蒙古 建材 科技','内蒙古超牌建材科技有限公司','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=102&id=10','0','99','0','2','qaz123','1364437439','1364437439','0');");
E_D("replace into `lt_yp_news` values('11','92','0','密友MYM卧式砂磨机获国家发明专利','','http://www.miyou.com.cn/upload/2012-10-11-4532e6d3a5-778b-417d-bdde-51033227ccf9.jpg','密友 卧式 砂磨机','密友集团粉体设备工程有限公司科技人员攻坚克难研发出一种高效率砂磨机--- MYM卧式砂磨机，该机采用经优化设计的机械密封，具有可靠性和耐用性，并配有与研磨物料相容性的冷却液，减少','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=11','0','99','0','10','zyn123','1365473317','1365473317','1');");
E_D("replace into `lt_yp_news` values('12','92','0','密友QYF、QYN型气流粉碎机被命名为国家级新产品','','http://kunshanmiyou.w173.mc-test.com/upload/2012-10-11-48d019c85f-3be8-4090-a086-e11f9f8474f0.jpg','密友 气流 粉碎机','近日，密友QYF、QYN型气流粉碎机被命名为国家级新产品，荣获省、苏州市科技进步奖，列入国家火炬计划。中药超细粉碎机成套装备为国家产业化示范工程项目。中药超细粉碎机组、WFJ涡轮式分','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=12','0','99','0','10','zyn123','1365473381','1365473381','1');");
E_D("replace into `lt_yp_news` values('13','92','0','密友公司SJM-3600L大型湿法搅拌磨机开发圆满成功','','','密友 公司 SJM-3600L','近日，由密友粉体设备工程有限公司自主投资研发的SJM-3600L大型湿法搅拌磨机经过测试，验收组验收，获得圆满成功。','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=13','0','99','0','10','zyn123','1365473476','1365473476','1');");
E_D("replace into `lt_yp_news` values('14','92','0','昆山密友QYF-400气流粉碎机，性能卓越倍受青睐','','http://file.youboy.com/a/73/10/35/1/7728581s.jpg','昆山 密友 QYF-400','QYF-400型气流粉碎机，是昆山密友粉体工程设备有限公司销售最多的一款型号设备，性能通过市场20多年的考验，相对投入和产出量适中，已经运用于各个行业。\r\n','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=14','0','99','0','10','zyn123','1365473562','1365473562','1');");
E_D("replace into `lt_yp_news` values('15','92','0','密友集团湿法磨设备在阻燃剂行业获得成功应用','','','密友 集团 湿法','近日，密友集团下属昆山密友粉碎设备有限公司生产的SJM系列湿法搅拌磨机在山东客户商生产阻燃剂行业成功使用。该设备为阻燃剂行业生产产量需求高的企业提供了新的生产制备解决方案，填','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=15','0','99','0','10','zyn123','1365473620','1365473620','1');");
E_D("replace into `lt_yp_news` values('16','92','0','贝克曼库尔特发布最新一款高效能纳米粒度及ZETA电位分析仪','','','贝克曼库尔特 发布最新 一款','　　2013年3月18日贝克曼库尔特发布最新一款高效能纳米粒度及ZETA电位分析仪。每年一度的全球最大型科学仪器展---美国费城PITTCON上，贝克...','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=16','0','99','0','4','aaa','1365560743','1365560743','1');");
E_D("replace into `lt_yp_news` values('17','92','0','粒度仪“以旧换新”优惠活动','','http://beckman.cnpowder.com.cn/img/article/2012/08/beckman-20120818013545-172.jpg','粒度 仪 以旧换新','　　贝克曼库尔特公司的粒度仪产品LS,Multisizer系列等进入中国已超过30年，在各行业各领域拥有广泛而大量的用户，先进的技术含量和优质的...','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=17','0','99','0','4','aaa','1365560806','1365560806','1');");
E_D("replace into `lt_yp_news` values('18','92','0','贝克曼库尔特发布新一代激光粒度仪','','','贝克曼库尔特 发布 新一代','　　美国贝克曼库尔特公司于2010年第一季度在其专业网站中正式发布新一代的LS系列纳米微米激光粒度分析仪。新的LS 13320 激光粒度仪将继...','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=92&id=18','0','99','0','4','aaa','1365560875','1365560875','1');");

require("../../inc/footer.php");
?>