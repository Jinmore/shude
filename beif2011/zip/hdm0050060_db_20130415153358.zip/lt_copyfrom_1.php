<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_copyfrom`;");
E_C("CREATE TABLE `lt_copyfrom` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sitename` varchar(30) NOT NULL,
  `siteurl` varchar(100) NOT NULL,
  `thumb` varchar(100) NOT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `lt_copyfrom` values('1','1','新华网','http://www.xinhuanet.com/','','0');");
E_D("replace into `lt_copyfrom` values('2','1','新浪网','http://www.sina.com.cn/','','0');");
E_D("replace into `lt_copyfrom` values('3','1','经济参考报','http://jjckb.xinhuanet.com/','','0');");
E_D("replace into `lt_copyfrom` values('4','1','中国矿业网','http://www.chinamining.com.cn/','','0');");
E_D("replace into `lt_copyfrom` values('5','1','工信部','http://www.miit.gov.cn/n11293472/index.html','','0');");

require("../../inc/footer.php");
?>