<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_yp_certificate`;");
E_C("CREATE TABLE `lt_yp_certificate` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `organization` varchar(100) DEFAULT NULL,
  `thumb` varchar(100) DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `addtime` int(10) DEFAULT NULL,
  `endtime` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8");
E_D("replace into `lt_yp_certificate` values('1','1','资质证书','资质证书','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327011059951.jpg','1','1362758400','1364572800');");

require("../../inc/footer.php");
?>