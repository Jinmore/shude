<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_poster_201304`;");
E_C("CREATE TABLE `lt_poster_201304` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `spaceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `area` char(40) NOT NULL,
  `ip` char(15) NOT NULL,
  `referer` char(120) NOT NULL,
  `clicktime` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`,`type`,`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `lt_poster_201304` values('1','1','1','0','','北京市','222.128.176.61','http://hmu178163.chinaw3.com/','1365300408','1');");
E_D("replace into `lt_poster_201304` values('2','6','1','0','','北京市','202.204.107.4','http://hmu178163.chinaw3.com/','1365324113','1');");
E_D("replace into `lt_poster_201304` values('3','9','1','0','','IANA','114.250.207.92','http://hmu178163.chinaw3.com/','1365583752','1');");
E_D("replace into `lt_poster_201304` values('4','44','1','0','','北京市','61.149.192.145','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=lists&catid=1','1365755678','1');");
E_D("replace into `lt_poster_201304` values('5','8','1','0','','中国','60.247.50.103','http://hmu178163.chinaw3.com/','1365833107','1');");

require("../../inc/footer.php");
?>