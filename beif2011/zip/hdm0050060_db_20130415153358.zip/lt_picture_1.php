<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_picture`;");
E_C("CREATE TABLE `lt_picture` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` char(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` varchar(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islink` int(10) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `lt_picture` values('1','509','0','对联左边广告一','','http://hmu178163.chinaw3.com/uploadfile/gg/dl_left_1.gif','对联 左边 广告','对联左边广告一','0','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=509&id=1','0','99','1','0','wz010','1364892918','1364982314');");
E_D("replace into `lt_picture` values('2','509','0','对联左边广告二','','http://hmu178163.chinaw3.com/uploadfile/gg/dl_left_2.gif','对联 左边 广告','对联左边广告二','0','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=509&id=2','0','99','1','0','wz010','1364892967','1364982327');");
E_D("replace into `lt_picture` values('3','509','0','对联右边广告一','','http://hmu178163.chinaw3.com/uploadfile/gg/dl_right_1.gif','对联 右边 广告','对联右边广告一','0','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=509&id=3','0','99','1','0','wz010','1364892986','1364982339');");
E_D("replace into `lt_picture` values('4','509','0','对联右边广告二','','http://hmu178163.chinaw3.com/uploadfile/gg/dl_right_2.gif','对联 右边 广告','对联右边广告二','0','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=show&catid=509&id=4','0','99','1','0','wz010','1364893008','1364982351');");

require("../../inc/footer.php");
?>