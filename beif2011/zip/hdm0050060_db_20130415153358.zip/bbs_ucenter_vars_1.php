<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_ucenter_vars`;");
E_C("CREATE TABLE `bbs_ucenter_vars` (
  `name` char(32) NOT NULL DEFAULT '',
  `value` char(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8");
E_D("replace into `bbs_ucenter_vars` values('noteexists','0');");
E_D("replace into `bbs_ucenter_vars` values('noteexists1','0');");

require("../../inc/footer.php");
?>