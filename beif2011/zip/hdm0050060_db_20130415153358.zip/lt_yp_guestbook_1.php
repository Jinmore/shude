<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_yp_guestbook`;");
E_C("CREATE TABLE `lt_yp_guestbook` (
  `gid` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL,
  `telephone` varchar(18) NOT NULL,
  `qq` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `dwgs` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `zip` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `url` varchar(150) DEFAULT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`gid`),
  KEY `userid` (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8");
E_D("replace into `lt_yp_guestbook` values('1','1','苏苏','15801035399','624245068','','','','','测试测试',NULL,NULL,'1','1364361633');");
E_D("replace into `lt_yp_guestbook` values('2','2','苏苏','15801035399','624245068@qq.com','北京市海淀区','龙鼎腾信','51667856','100193','测试在线留言',NULL,NULL,'1','1364892548');");

require("../../inc/footer.php");
?>