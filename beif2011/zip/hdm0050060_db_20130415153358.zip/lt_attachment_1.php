<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_attachment`;");
E_C("CREATE TABLE `lt_attachment` (
  `aid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `module` char(15) NOT NULL,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `filename` char(50) NOT NULL,
  `filepath` char(200) NOT NULL,
  `filesize` int(10) unsigned NOT NULL DEFAULT '0',
  `fileext` char(10) NOT NULL,
  `isimage` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `isthumb` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `downloads` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uploadtime` int(10) unsigned NOT NULL DEFAULT '0',
  `uploadip` char(15) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `authcode` char(32) NOT NULL,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`aid`),
  KEY `authcode` (`authcode`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=utf8");
E_D("replace into `lt_attachment` values('4','yp','0','qy_logo.jpg','2013/0327/20130327011059951.jpg','12313','jpg','1','0','0','1','1364361059','127.0.0.1','1','414f295dd17551d140cec48238579377','1');");
E_D("replace into `lt_attachment` values('7','content','0','仟禧农业修改.doc','2013/0327/20130327040823783.doc','295936','doc','0','0','0','1','1364371703','127.0.0.1','1','f9ef63433e0ea66f4e785f37602fb64f','1');");
E_D("replace into `lt_attachment` values('6','content','0','pic.jpg','2013/0327/20130327025048676.jpg','49168','jpg','1','0','0','1','1364367048','127.0.0.1','1','cf5ab8fa891c37b709fd55c53ff72165','1');");
E_D("replace into `lt_attachment` values('8','content','0','pic2.jpg','2013/0327/20130327050848318.jpg','11876','jpg','1','0','0','1','1364375328','127.0.0.1','1','a97b0aa48cec47a496ac3b2a08bb1876','1');");
E_D("replace into `lt_attachment` values('9','content','0','pic3.jpg','2013/0327/20130327051451766.jpg','13833','jpg','1','0','0','1','1364375691','127.0.0.1','1','a2264a98cc154530ec8901dc71eaf4b5','1');");
E_D("replace into `lt_attachment` values('10','content','0','pic4.jpg','2013/0327/20130327051528221.jpg','8466','jpg','1','0','0','1','1364375728','127.0.0.1','1','82e32991a753bb847161f13848c2264b','1');");
E_D("replace into `lt_attachment` values('11','content','0','pic4.jpg','2013/0328/20130328020241484.jpg','8466','jpg','1','0','0','1','1364450561','127.0.0.1','1','fdab52dac7ecfc5ff9c53336cfdcd2d3','1');");
E_D("replace into `lt_attachment` values('12','content','0','pic2.jpg','2013/0328/20130328020241245.jpg','11876','jpg','1','0','0','1','1364450561','127.0.0.1','1','07ce0c9acaf16b6361ce4e1682a787cd','1');");
E_D("replace into `lt_attachment` values('13','content','0','pic3.jpg','2013/0328/20130328020241521.jpg','13833','jpg','1','0','0','1','1364450561','127.0.0.1','1','261b47f12aaa80bd13100b5a5cbfa207','1');");
E_D("replace into `lt_attachment` values('14','content','377','pic.jpg','2013/0329/20130329125241590.jpg','10412','jpg','1','0','0','1','1364532761','127.0.0.1','1','2415cb95a8e53e3988f28767f3ae83b9','1');");
E_D("replace into `lt_attachment` values('15','content','9','1.jpg','2013/0403/20130403015750991.jpg','50677','jpg','1','0','0','1','1364968670','222.129.39.108','1','94f76d8515d5c88be352b7e66796646c','1');");
E_D("replace into `lt_attachment` values('16','content','0','20130403020021985.jpg','2013/0403/20130403020021985.jpg','76424','jpg','1','0','0','0','1364968821','222.129.39.108','1','5ee5619e846455255e88257e409070f9','1');");
E_D("replace into `lt_attachment` values('17','content','0','20130403020023209.jpg','2013/0403/20130403020023209.jpg','66361','jpg','1','0','0','0','1364968821','222.129.39.108','1','03be9217b6af8859b8982d757c8165fe','1');");
E_D("replace into `lt_attachment` values('18','content','0','20130403020024849.jpg','2013/0403/20130403020024849.jpg','56557','jpg','1','0','0','0','1364968821','222.129.39.108','1','c646df9b6df80f5f2d037b515d9394a0','1');");
E_D("replace into `lt_attachment` values('19','content','0','20130403020024496.jpg','2013/0403/20130403020024496.jpg','42345','jpg','1','0','0','0','1364968821','222.129.39.108','1','e4dd2ab0d6fdee1ec8e90a2b614110ac','1');");
E_D("replace into `lt_attachment` values('20','content','0','20130403020025445.jpg','2013/0403/20130403020025445.jpg','42616','jpg','1','0','0','0','1364968821','222.129.39.108','1','9c72d9e95a29a3f825b4b9c29a00fc15','1');");
E_D("replace into `lt_attachment` values('21','content','0','20130403020025217.jpg','2013/0403/20130403020025217.jpg','51539','jpg','1','0','0','0','1364968821','222.129.39.108','1','7f97246d9e5f1eecc595ebf0f0f886fe','1');");
E_D("replace into `lt_attachment` values('22','content','0','20130403020026639.jpg','2013/0403/20130403020026639.jpg','54133','jpg','1','0','0','0','1364968821','222.129.39.108','1','b0856d774d90a3271357a5c2b3f74052','1');");
E_D("replace into `lt_attachment` values('23','content','0','20130403020027270.jpg','2013/0403/20130403020027270.jpg','35710','jpg','1','0','0','0','1364968821','222.129.39.108','1','e386953586613778207bd6e44cae5259','1');");
E_D("replace into `lt_attachment` values('24','content','12','20121024001.jpg','2013/0403/20130403041731668.jpg','22928','jpg','1','0','0','1','1364977051','222.129.39.108','0','b64fb6986df93d5a4520dfd784770e2d','1');");
E_D("replace into `lt_attachment` values('25','content','12','20121105001.jpg','2013/0403/20130403042111238.jpg','23335','jpg','1','0','0','1','1364977270','222.129.39.108','1','6231e412d1cb0614089236d6b119d0cd','1');");
E_D("replace into `lt_attachment` values('26','content','12','20121120001.jpg','2013/0403/20130403042202866.jpg','22649','jpg','1','0','0','1','1364977322','222.129.39.108','1','e58159e78ed2995697890c49204ae67b','1');");
E_D("replace into `lt_attachment` values('27','content','12','20121203001.jpg','2013/0403/20130403044757893.jpg','22555','jpg','1','0','0','1','1364978876','222.129.39.108','1','ce11ec6f67bba7474295afafb3b7ab44','1');");
E_D("replace into `lt_attachment` values('28','content','12','20130104001.jpg','2013/0403/20130403044911133.jpg','21915','jpg','1','0','0','1','1364978951','222.129.39.108','1','fdbef0dcb4d56da5ae2c2b71cf15c834','1');");
E_D("replace into `lt_attachment` values('29','content','12','20130314001.jpg','2013/0403/20130403045019414.jpg','23213','jpg','1','0','0','1','1364979019','222.129.39.108','1','97c0ccdc35cb7ecfb3cea6e0a309b0f1','1');");
E_D("replace into `lt_attachment` values('30','content','13','image.jpg','2013/0403/20130403052701532.jpg','115213','jpg','1','0','0','1','1364981221','222.129.39.108','1','8cd7d6bb00a3c3ca982669aff2e198b7','1');");
E_D("replace into `lt_attachment` values('31','content','17','image.jpg','2013/0403/20130403094256772.jpg','216137','jpg','1','0','0','1','1364996576','111.193.250.11','1','4282169eed71cc992aa730c6eee96e53','1');");
E_D("replace into `lt_attachment` values('32','content','17','image.jpg','2013/0403/20130403094302984.jpg','216137','jpg','1','0','0','1','1364996581','111.193.250.11','1','94cfcef27417d866cfa1805b01311633','1');");
E_D("replace into `lt_attachment` values('33','content','499','1.jpg','2013/0403/20130403102952395.jpg','4345','jpg','1','0','0','1','1364999392','111.193.250.11','0','62b692cff18120aada0bd034e19e1231','1');");
E_D("replace into `lt_attachment` values('34','content','0','20130405022359113.jpg','2013/0405/20130405022359113.jpg','8523','jpg','1','0','0','0','1365143038','111.194.157.176','1','d05c0064b67f41330f053c457e0ffbad','1');");
E_D("replace into `lt_attachment` values('35','content','0','20130405022400180.jpg','2013/0405/20130405022400180.jpg','8573','jpg','1','0','0','0','1365143038','111.194.157.176','1','bd86b2b0f6b5b095b2ffec9c71d888c5','1');");
E_D("replace into `lt_attachment` values('36','content','0','20130405022400116.jpg','2013/0405/20130405022400116.jpg','9406','jpg','1','0','0','0','1365143038','111.194.157.176','1','5d76e0bbcf2a21fb97c6975f87977414','1');");
E_D("replace into `lt_attachment` values('37','content','0','20130405022400196.jpg','2013/0405/20130405022400196.jpg','9746','jpg','1','0','0','0','1365143038','111.194.157.176','1','4cc0e4c5f02c4fa1e605cc14d48693f0','1');");
E_D("replace into `lt_attachment` values('38','content','14','1.jpg','2013/0405/20130405024239444.jpg','23010','jpg','1','0','0','1','1365144158','111.194.157.176','1','c94a8d8e048f281137a71c1114d76ee3','1');");
E_D("replace into `lt_attachment` values('39','content','486','1.jpg','2013/0407/20130407095426316.jpg','5674','jpg','1','0','0','1','1365299666','222.129.55.71','1','ed4f04575023e6609835d8c40e922d8d','1');");
E_D("replace into `lt_attachment` values('40','content','49','2.jpg','2013/0407/20130407102140559.jpg','6243','jpg','1','0','0','1','1365301300','222.129.55.71','1','1b073ddcd309627cd0ffb5ecbb237205','1');");
E_D("replace into `lt_attachment` values('41','content','39','mq-1.jpg','2013/0407/20130407021204785.jpg','7200','jpg','1','0','0','1','1365315124','222.129.55.71','1','041f430807b20e0a08d8b8bb65928721','1');");
E_D("replace into `lt_attachment` values('42','content','39','mq-2.jpg','2013/0407/20130407021205508.jpg','8630','jpg','1','0','0','1','1365315125','222.129.55.71','1','9ad2b6e674c5e18afc6277577f2ac535','1');");
E_D("replace into `lt_attachment` values('43','content','39','mq-3.jpg','2013/0407/20130407021206196.jpg','6367','jpg','1','0','0','1','1365315126','222.129.55.71','1','b815882603c1f58d02367c8cbdd4ad67','1');");
E_D("replace into `lt_attachment` values('44','content','39','mq-4.jpg','2013/0407/20130407021206565.jpg','8056','jpg','1','0','0','1','1365315126','222.129.55.71','1','c13ef6b1c2e8e74a62e27b0ad814522c','1');");
E_D("replace into `lt_attachment` values('45','content','39','mq-5.jpg','2013/0407/20130407021207603.jpg','7090','jpg','1','0','0','1','1365315127','222.129.55.71','1','7f9a3bce5a1bf913a2ae8be6896ee351','1');");
E_D("replace into `lt_attachment` values('46','content','39','mq-6.jpg','2013/0407/20130407021208246.jpg','3949','jpg','1','0','0','1','1365315127','222.129.55.71','1','fd73066ae73c5307289c1bc1838feb27','1');");
E_D("replace into `lt_attachment` values('47','content','39','mq-7.jpg','2013/0407/20130407021208267.jpg','6325','jpg','1','0','0','1','1365315128','222.129.55.71','1','3244fdd0759215831f5a572e9631d21b','1');");
E_D("replace into `lt_attachment` values('48','content','39','mq-8.jpg','2013/0407/20130407021209806.jpg','6105','jpg','1','0','0','1','1365315128','222.129.55.71','1','0efde876a54bd5e1df639b897517750c','1');");
E_D("replace into `lt_attachment` values('49','content','39','mq-9.jpg','2013/0407/20130407021209419.jpg','6297','jpg','1','0','0','1','1365315129','222.129.55.71','1','42a3f38f31a2f7ce6b7fb3fd0d2a5bcc','1');");
E_D("replace into `lt_attachment` values('50','content','39','mq-10.jpg','2013/0407/20130407021209993.jpg','6842','jpg','1','0','0','1','1365315129','222.129.55.71','1','c7ca843288e4f5199db9743c0763ca8f','1');");
E_D("replace into `lt_attachment` values('51','content','39','mq-11.jpg','2013/0407/20130407021243351.jpg','5355','jpg','1','0','0','1','1365315163','222.129.55.71','1','f91b48114c8f6c20ce1a3b235c1dd87a','1');");
E_D("replace into `lt_attachment` values('52','content','39','mq-12.jpg','2013/0407/20130407021244367.jpg','3901','jpg','1','0','0','1','1365315164','222.129.55.71','1','02ab640f66f2a7c5e7def798d265ae97','1');");
E_D("replace into `lt_attachment` values('53','content','499','ls-1.jpg','2013/0407/20130407041321386.jpg','3288','jpg','1','0','0','1','1365322401','222.129.55.71','1','65a0915a17c6a81e1835b25d45d8a776','1');");
E_D("replace into `lt_attachment` values('54','content','499','ls-2.jpg','2013/0407/20130407041322232.jpg','4543','jpg','1','0','0','1','1365322402','222.129.55.71','1','f9b329813d04ffc8094fd5d1c166a76c','1');");
E_D("replace into `lt_attachment` values('55','content','499','ls-3.jpg','2013/0407/20130407041322661.jpg','4716','jpg','1','0','0','1','1365322402','222.129.55.71','1','f63458b15d127cb73bcfe31272030af6','1');");
E_D("replace into `lt_attachment` values('56','content','499','ls-4.jpg','2013/0407/20130407041322550.jpg','5346','jpg','1','0','0','1','1365322402','222.129.55.71','1','199285160477a2ba67c4d7d960d029fa','1');");
E_D("replace into `lt_attachment` values('57','content','499','ls-5.jpg','2013/0407/20130407041323523.jpg','6782','jpg','1','0','0','1','1365322403','222.129.55.71','1','e59a528cd45440ad1f31ea44171b22d0','1');");
E_D("replace into `lt_attachment` values('58','content','499','ls-6.jpg','2013/0407/20130407041323418.jpg','6388','jpg','1','0','0','1','1365322403','222.129.55.71','1','593b835f08e4b1a2750b3e9c16780deb','1');");
E_D("replace into `lt_attachment` values('59','content','25','zhuanjia-1.jpg','2013/0408/20130408090453136.jpg','25836','jpg','1','0','0','1','1365383093','61.149.195.46','1','3102bd155063514b4273db242ca22f45','1');");
E_D("replace into `lt_attachment` values('60','content','25','zhuanjia-2.jpg','2013/0408/20130408092209356.jpg','33311','jpg','1','0','0','1','1365384129','61.149.195.46','1','e0400d8c39e8cd5068d14115b9a6526a','1');");
E_D("replace into `lt_attachment` values('61','content','25','zhuanjia-3.jpg','2013/0408/20130408092359138.jpg','30646','jpg','1','0','0','1','1365384239','61.149.195.46','1','52107de3d488893f995817c16af43f63','1');");
E_D("replace into `lt_attachment` values('62','content','25','zhuanjia-4.jpg','2013/0408/20130408092637173.jpg','28593','jpg','1','0','0','1','1365384397','61.149.195.46','1','b6efb244ad905dc38e9e22fc9a326d41','1');");
E_D("replace into `lt_attachment` values('63','content','25','zhuanjia-5.jpg','2013/0408/20130408092845596.jpg','31508','jpg','1','0','0','1','1365384525','61.149.195.46','1','6556b6f5201422d35b567f6c3444ed20','1');");
E_D("replace into `lt_attachment` values('64','content','25','zhuanjia-6.jpg','2013/0408/20130408093221743.jpg','35657','jpg','1','0','0','1','1365384741','61.149.195.46','1','f631bfa5092283591676b24377c0ff42','1');");
E_D("replace into `lt_attachment` values('65','content','0','MYM-wssmj.jpg','2013/0408/20130408111909213.jpg','31014','jpg','1','0','0','1','1365391149','61.149.195.46','1','2520732d70f2e9eafea0e9d9470591e9','1');");
E_D("replace into `lt_attachment` values('66','content','0','XYD-gjjwmfjj.jpg','2013/0408/20130408112510896.jpg','10997','jpg','1','0','0','1','1365391510','61.149.195.46','1','afaf98232c28d9f670982508e8036972','1');");
E_D("replace into `lt_attachment` values('67','content','0','QYF-lhqqlfcj.jpg','2013/0408/20130408113429114.jpg','15281','jpg','1','0','0','1','1365392069','61.149.195.46','1','435576dc92e52c5f204df700433e9081','1');");
E_D("replace into `lt_attachment` values('68','content','0','WFJ-wmfjj.jpg','2013/0408/20130408125705336.jpg','13303','jpg','1','0','0','1','1365397025','61.149.195.46','1','1f822091013336be38420b77ae4faf42','1');");
E_D("replace into `lt_attachment` values('69','content','27','103x103.jpg','2013/0408/20130408023828595.jpg','557022','jpg','1','0','0','1','1365403108','61.149.195.46','1','ced4dcd6f4b1436fbe45687a3196c169','1');");
E_D("replace into `lt_attachment` values('70','content','27','测试文件.doc','2013/0408/20130408025559635.doc','27136','doc','0','0','0','1','1365404159','61.149.195.46','1','e796ccf4cff24aeb492298cf69fb28c0','1');");
E_D("replace into `lt_attachment` values('72','content','0','GYGX-qyhm.jpg','2013/0408/20130408053233953.jpg','15883','jpg','1','0','0','1','1365413553','61.149.195.46','1','6e9b0e02ac7b62eae2eac5276f76e44b','1');");
E_D("replace into `lt_attachment` values('73','content','0','FJS-gyzztsg.jpg','2013/0409/20130409093900487.jpg','1295','jpg','1','0','0','1','1365471540','61.149.194.81','1','6c7cc3cb0deed6e31c6057080e7fc434','1');");
E_D("replace into `lt_attachment` values('74','content','0','GLT-cbdsglt.jpg','2013/0409/20130409094153581.jpg','1696','jpg','1','0','0','1','1365471713','61.149.194.81','1','286fceaff9f48499d5b86db45621c463','1');");
E_D("replace into `lt_attachment` values('75','content','0','YM-jymf.jpg','2013/0409/20130409094413692.jpg','1260','jpg','1','0','0','1','1365471853','61.149.194.81','1','3d93e3fa74faa60b80b486ee42700746','1');");
E_D("replace into `lt_attachment` values('76','content','0','ZJS-ggb.jpg','2013/0409/20130409094605991.jpg','1420','jpg','1','0','0','1','1365471965','61.149.194.81','1','d1d35a2b73ade18a7ac345b5b9ccc020','1');");
E_D("replace into `lt_attachment` values('77','content','0','ZJS-zjsf.jpg','2013/0409/20130409094720646.jpg','1420','jpg','1','0','0','1','1365472040','61.149.194.81','1','32883d415cf052a2f49bc37e09116853','1');");
E_D("replace into `lt_attachment` values('78','content','0','SY-gwf.jpg','2013/0409/20130409094909656.jpg','1057','jpg','1','0','0','1','1365472149','61.149.194.81','1','de9880b859e7b0c412111dcd0562c59d','1');");
E_D("replace into `lt_attachment` values('79','content','27','20130409101807986.doc','2013/0409/20130409101807260.doc','20480','doc','0','0','0','1','1365473887','61.149.194.81','1','2a4e9f3e24a53eaeb9f4fe5588eafc78','1');");
E_D("replace into `lt_attachment` values('80','content','27','硅酸盐在橡胶补强中的应用.doc','2013/0409/20130409102132472.doc','25088','doc','0','0','0','1','1365474092','61.149.194.81','1','12b514a59b9d00d5f1e6e409ab7d28a2','1');");
E_D("replace into `lt_attachment` values('81','content','27','20130409102527189.doc','2013/0409/20130409102527470.doc','25088','doc','0','0','0','1','1365474327','61.149.194.81','1','0a05b52a47f1841c09b9b8987f52c5d6','1');");
E_D("replace into `lt_attachment` values('82','content','27','超微粉碎技术在中药生产中的应用.doc','2013/0409/20130409102640654.doc','24576','doc','0','0','0','1','1365474400','61.149.194.81','1','915c178dff4b682edf2e4ce7f2570fc7','1');");
E_D("replace into `lt_attachment` values('83','content','27','20130409102819972.doc','2013/0409/20130409102819391.doc','24576','doc','0','0','0','1','1365474499','61.149.194.81','1','fe81d9a5b97c651975bbdd8b581c7fde','1');");
E_D("replace into `lt_attachment` values('84','yp','0','miyou.jpg','2013/0409/20130409103828683.jpg','8481','jpg','1','0','0','1','1365475108','61.149.194.81','1','98dd401eea40fac6ceb4c8ae35b6c169','1');");
E_D("replace into `lt_attachment` values('85','content','40','20130409100918989.jpg','2013/0409/20130409104250520.jpg','33195','jpg','1','0','0','1','1365475370','61.149.194.81','1','90731d0da9f427da83d261a1e518c461','1');");
E_D("replace into `lt_attachment` values('86','yp','0','nadazijin.jpg','2013/0409/20130409105535392.jpg','8287','jpg','1','0','0','1','1365476135','61.149.194.81','1','d2513f6eee85b9a8f9c91812fbb95688','1');");
E_D("replace into `lt_attachment` values('87','yp','0','jsndj.png','2013/0409/20130409111941102.png','15302','png','1','0','0','1','1365477581','61.149.194.81','1','249bd1d364cc1dacfe9830cd16d3def0','1');");
E_D("replace into `lt_attachment` values('88','yp','0','naichi.jpg','2013/0409/20130409123806242.jpg','8859','jpg','1','0','0','1','1365482286','61.149.194.81','1','8f9c70654152dcca8c734cad0681e1c8','1');");
E_D("replace into `lt_attachment` values('89','yp','0','zjfl.jpg','2013/0409/20130409011638171.jpg','5899','jpg','1','0','0','1','1365484598','61.149.194.81','1','503de6b310e5e531929679cb9852223c','1');");
E_D("replace into `lt_attachment` values('90','yp','0','yanshan.jpg','2013/0410/20130410092746989.jpg','6603','jpg','1','0','0','1','1365557266','222.129.42.9','1','120a10d7035aac0fa6004489c1770cb2','1');");
E_D("replace into `lt_attachment` values('91','content','0','SSJ-na.jpg','2013/0410/20130410093055456.jpg','18869','jpg','1','0','0','1','1365557455','222.129.42.9','1','ae9cbefc5dc9f23fbed42747ed204775','1');");
E_D("replace into `lt_attachment` values('92','yp','0','mgbkmk.jpg','2013/0410/20130410095753861.jpg','5841','jpg','1','0','0','1','1365559073','222.129.42.9','1','76cebf88a959819797e292e6253693a9','1');");
E_D("replace into `lt_attachment` values('93','content','0','LDY-ket.jpg','2013/0410/20130410100250995.jpg','6146','jpg','1','0','0','1','1365559370','222.129.42.9','1','ed2689a8ad23c6cb0da382d4673077d0','1');");
E_D("replace into `lt_attachment` values('94','content','0','LDY-ketjg.jpg','2013/0410/20130410100440992.jpg','5953','jpg','1','0','0','1','1365559480','222.129.42.9','1','2a580cff3fc3b21c658f3705a47cb4bd','1');");
E_D("replace into `lt_attachment` values('95','content','0','LDY-gmd.jpg','2013/0410/20130410101803910.jpg','5029','jpg','1','0','0','1','1365560283','222.129.42.9','1','43ccd5e6fee9489aae177c48ec8533c4','1');");
E_D("replace into `lt_attachment` values('96','content','0','LDY-xbjs.jpg','2013/0410/20130410101955892.jpg','7763','jpg','1','0','0','1','1365560395','222.129.42.9','1','615170ce2a0740ba04dc4f630bebb220','1');");
E_D("replace into `lt_attachment` values('97','content','0','KLTX-klxt.jpg','2013/0410/20130410102317312.jpg','4596','jpg','1','0','0','1','1365560597','222.129.42.9','1','3d4e52cc60471ce70031572e48e4feee','1');");
E_D("replace into `lt_attachment` values('98','yp','0','dqw.jpg','2013/0410/20130410111259683.jpg','4669','jpg','1','0','0','1','1365563579','222.129.42.9','1','32a917cfa165d1f9f1f0f419ff2c3a49','1');");
E_D("replace into `lt_attachment` values('99','yp','0','dcjh.jpg','2013/0410/20130410123815965.jpg','5296','jpg','1','0','0','1','1365568695','222.129.42.9','1','584fdcdcaf33056368524f9c974487f9','1');");
E_D("replace into `lt_attachment` values('100','content','0','LDY-S35.jpg','2013/0410/20130410124158629.jpg','3718','jpg','1','0','0','1','1365568918','222.129.42.9','1','f0ba7d6c82770d645f131f3174e9688c','1');");
E_D("replace into `lt_attachment` values('101','content','0','LDY-mgmqk.jpg','2013/0410/20130410124331411.jpg','5120','jpg','1','0','0','1','1365569011','222.129.42.9','1','e8fc362408240d3d39a9aa64c0e942bb','1');");
E_D("replace into `lt_attachment` values('102','yp','0','aks.jpg','2013/0410/20130410124930979.jpg','5362','jpg','1','0','0','1','1365569370','222.129.42.9','0','e8f95f5520ae56767c4e24a97a494fc4','1');");
E_D("replace into `lt_attachment` values('103','content','0','DSCC-up.jpg','2013/0410/20130410125431482.jpg','13471','jpg','1','0','0','1','1365569671','222.129.42.9','1','c97c9c6cc21cab4255db737f410cbd77','1');");
E_D("replace into `lt_attachment` values('104','content','29','huanbao.jpg','2013/0410/20130410032925983.jpg','6863','jpg','1','0','0','1','1365578965','222.129.42.9','1','13ba0df145eb765793113046fc1a8ac3','1');");
E_D("replace into `lt_attachment` values('105','content','29','fedlcbeijing.jpg','2013/0410/20130410033606840.jpg','13693','jpg','1','0','0','1','1365579366','222.129.42.9','1','f72e9d4ea42004c4633aaf9dff6e0e3f','1');");
E_D("replace into `lt_attachment` values('106','content','27','问题修改2-4-11.doc','2013/0411/20130411041852433.doc','33280','doc','0','0','0','1','1365668332','222.129.36.111','1','dbb78ca171d11f230d0cd5ea3cf363a8','1');");
E_D("replace into `lt_attachment` values('107','content','30','1.jpg','2013/0412/20130412022907446.jpg','67424','jpg','1','0','0','1','1365748147','61.149.192.145','1','ba64ad60190fb351451d3d9765fcd228','1');");
E_D("replace into `lt_attachment` values('108','content','41','2.jpg','2013/0412/20130412030750431.jpg','23829','jpg','1','0','0','1','1365750470','61.149.192.145','1','eee3fd6a2d3d50c8339d41101aae13d5','1');");
E_D("replace into `lt_attachment` values('109','content','48','1.jpg','2013/0412/20130412033957339.jpg','10263','jpg','1','0','0','1','1365752397','61.149.192.145','1','378188009ad83e5e1aaf78fe62958d22','1');");
E_D("replace into `lt_attachment` values('110','content','48','2.jpg','2013/0412/20130412034626682.jpg','12391','jpg','1','0','0','1','1365752786','61.149.192.145','1','de004bf75a9875200992ddcff6446dc7','1');");
E_D("replace into `lt_attachment` values('111','content','48','3.jpg','2013/0412/20130412034905899.jpg','7001','jpg','1','0','0','1','1365752945','61.149.192.145','1','0837adc681e2fba92dcd68aac36abe4c','1');");
E_D("replace into `lt_attachment` values('112','content','48','4.jpg','2013/0412/20130412035215997.jpg','8424','jpg','1','0','0','1','1365753135','61.149.192.145','1','f7c990702a3bc8af38e2b2139a522984','1');");
E_D("replace into `lt_attachment` values('113','content','48','5.jpg','2013/0412/20130412040440791.jpg','10402','jpg','1','0','0','1','1365753880','61.149.192.145','1','29c117914d7ea49d3d1d39f3110ea89f','1');");

require("../../inc/footer.php");
?>