<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_model`;");
E_C("CREATE TABLE `lt_model` (
  `modelid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `name` char(30) NOT NULL,
  `description` char(100) NOT NULL,
  `tablename` char(20) NOT NULL,
  `setting` text NOT NULL,
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  `items` smallint(5) unsigned NOT NULL DEFAULT '0',
  `enablesearch` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `default_style` char(30) NOT NULL,
  `category_template` char(30) NOT NULL,
  `list_template` char(30) NOT NULL,
  `show_template` char(30) NOT NULL,
  `js_template` varchar(30) NOT NULL,
  `admin_list_template` char(30) NOT NULL,
  `member_add_template` varchar(30) NOT NULL,
  `sort` tinyint(3) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`modelid`),
  KEY `type` (`type`,`siteid`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8");
E_D("replace into `lt_model` values('1','1','文章模型','','news','','0','0','1','0','default','category','list','show','','','','0','0');");
E_D("replace into `lt_model` values('3','1','图片模型','','picture','','0','0','1','0','default','category_picture','list_picture','show_picture','','','','0','0');");
E_D("replace into `lt_model` values('10','1','普通会员','普通会员','member_detail','','0','0','1','0','','','','','','','','0','2');");
E_D("replace into `lt_model` values('12','1','企业库','企业会员','yp_company','array (\n  ''ismenu'' => ''0'',\n  ''meta_title'' => '''',\n  ''meta_keywords'' => '''',\n  ''meta_description'' => '''',\n)','1364353798','0','1','0','','','','','','','','0','4');");
E_D("replace into `lt_model` values('13','1','新闻','','yp_news','array (\n  ''ismenu'' => ''1'',\n  ''meta_title'' => ''企业信息'',\n  ''meta_keywords'' => ''企业信息'',\n  ''meta_description'' => ''中国最全的黄页信息'',\n)','1364353798','0','1','0','default','model_product','list_news','show_news','','','','0','5');");
E_D("replace into `lt_model` values('14','1','产品','','yp_product','array (\n  ''ismenu'' => ''1'',\n  ''meta_title'' => ''企业产品'',\n  ''meta_keywords'' => ''企业产品，中国粉体网'',\n  ''meta_description'' => ''亚洲最大网上购物网站——打造的在线B2C购物平台（B2C，Business to Customer）。在商城购物，享受100%正品保障、7天退换货、提供发票的服务。加入商城，将为全新的B2C事业创造更多的奇迹。'',\n)','1364353798','0','1','0','default','model_product','list_product','show_product','','','','0','5');");
E_D("replace into `lt_model` values('16','1','技术咨询','技术咨询','jszx','array (\n  ''enabletime'' => ''0'',\n  ''starttime'' => ''1364832000'',\n  ''endtime'' => '''',\n  ''sendmail'' => ''0'',\n  ''mails'' => '''',\n  ''allowmultisubmit'' => ''1'',\n  ''allowunreg'' => ''1'',\n)','1364891590','9','1','0','default','','','show','show_js','','','0','3');");
E_D("replace into `lt_model` values('17','1','企业会员','企业会员','member_qyhy','','0','0','1','0','','','','','','','','0','2');");

require("../../inc/footer.php");
?>