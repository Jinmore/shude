<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_forum_thread`;");
E_C("CREATE TABLE `bbs_forum_thread` (
  `tid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `fid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `posttableid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `sortid` smallint(6) unsigned NOT NULL DEFAULT '0',
  `readperm` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `price` smallint(6) NOT NULL DEFAULT '0',
  `author` char(15) NOT NULL DEFAULT '',
  `authorid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `subject` char(80) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `lastpost` int(10) unsigned NOT NULL DEFAULT '0',
  `lastposter` char(15) NOT NULL DEFAULT '',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `replies` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `displayorder` tinyint(1) NOT NULL DEFAULT '0',
  `highlight` tinyint(1) NOT NULL DEFAULT '0',
  `digest` tinyint(1) NOT NULL DEFAULT '0',
  `rate` tinyint(1) NOT NULL DEFAULT '0',
  `special` tinyint(1) NOT NULL DEFAULT '0',
  `attachment` tinyint(1) NOT NULL DEFAULT '0',
  `moderated` tinyint(1) NOT NULL DEFAULT '0',
  `closed` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `stickreply` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `recommends` smallint(6) NOT NULL DEFAULT '0',
  `recommend_add` smallint(6) NOT NULL DEFAULT '0',
  `recommend_sub` smallint(6) NOT NULL DEFAULT '0',
  `heats` int(10) unsigned NOT NULL DEFAULT '0',
  `status` smallint(6) unsigned NOT NULL DEFAULT '0',
  `isgroup` tinyint(1) NOT NULL DEFAULT '0',
  `favtimes` mediumint(8) NOT NULL DEFAULT '0',
  `sharetimes` mediumint(8) NOT NULL DEFAULT '0',
  `stamp` tinyint(3) NOT NULL DEFAULT '-1',
  `icon` tinyint(3) NOT NULL DEFAULT '-1',
  `pushedaid` mediumint(8) NOT NULL DEFAULT '0',
  `cover` smallint(6) NOT NULL DEFAULT '0',
  `replycredit` smallint(6) NOT NULL DEFAULT '0',
  `relatebytag` char(255) NOT NULL DEFAULT '0',
  `maxposition` int(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`tid`),
  KEY `digest` (`digest`),
  KEY `sortid` (`sortid`),
  KEY `displayorder` (`fid`,`displayorder`,`lastpost`),
  KEY `typeid` (`fid`,`typeid`,`displayorder`,`lastpost`),
  KEY `recommends` (`recommends`),
  KEY `heats` (`heats`),
  KEY `authorid` (`authorid`),
  KEY `isgroup` (`isgroup`,`lastpost`),
  KEY `special` (`special`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `bbs_forum_thread` values('1','2','0','0','0','0','0','wz010','1','锦昊辉矿业发展有限公司硫酸钡春季促销','1365319879','1365319879','wz010','3','0','0','0','0','0','0','0','0','0','0','0','0','0','0','32','0','0','0','-1','20','0','0','0','1365319880	','0');");
E_D("replace into `bbs_forum_thread` values('2','2','0','0','0','0','0','wz010','1','几种非金属矿物在建筑涂料改性中的应用','1365321300','1365321300','wz010','2','0','0','0','0','0','0','0','0','0','0','0','0','0','0','32','0','0','0','-1','-1','0','0','0','1365326619	','0');");
E_D("replace into `bbs_forum_thread` values('3','37','0','0','0','0','0','wz010','1','纳米颗粒成为抗肿瘤药物“助推器”','1365321416','1365321416','wz010','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','32','0','0','0','-1','-1','0','0','0','1365321416	1,1','0');");
E_D("replace into `bbs_forum_thread` values('4','37','0','0','0','0','0','wz010','1','国家纳米中心提出高吸光性富勒烯材料设计新思路','1365321636','1365321636','wz010','5','0','0','0','0','0','0','0','0','0','0','0','0','0','0','32','0','0','0','-1','-1','0','0','0','1365592143	3','0');");
E_D("replace into `bbs_forum_thread` values('5','2','0','0','0','0','0','wz010','1','纳米光学质谱仪或可用于癌细胞检测','1365750045','1365750045','wz010','1','0','0','0','0','0','0','0','0','0','0','0','0','0','0','32','0','0','0','-1','-1','0','0','0','1365750045	3,4','0');");

require("../../inc/footer.php");
?>