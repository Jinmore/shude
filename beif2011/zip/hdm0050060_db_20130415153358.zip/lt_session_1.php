<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_session`;");
E_C("CREATE TABLE `lt_session` (
  `sessionid` char(32) NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `ip` char(15) NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL DEFAULT '0',
  `roleid` tinyint(3) unsigned DEFAULT '0',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL,
  `c` char(20) NOT NULL,
  `a` char(20) NOT NULL,
  `data` char(255) NOT NULL,
  PRIMARY KEY (`sessionid`),
  KEY `lastvisit` (`lastvisit`)
) ENGINE=MEMORY DEFAULT CHARSET=utf8");
E_D("replace into `lt_session` values('6a0638e43c857d544ffc2b6acc485cc1','0','61.149.197.36','1366008338','0','0','member','index','login','');");
E_D("replace into `lt_session` values('258a27c81a0172394014d886d2cf8496','0','220.181.132.199','1366009554','0','0','member','index','register','');");
E_D("replace into `lt_session` values('48051fc5b7fe05aa3ab897d80f1b16b5','0','220.181.132.196','1366009323','0','0','member','index','register','');");
E_D("replace into `lt_session` values('6c0f5951d5f6e82f41e31027f4f91141','1','61.149.197.36','1366008862','1','0','admin','index','public_session_life','code|s:4:\"uuyw\";userid|s:1:\"1\";roleid|s:1:\"1\";pc_hash|s:6:\"Td3BGS\";lock_screen|i:0;');");
E_D("replace into `lt_session` values('c672184b977019e80968433899090457','0','61.149.197.36','1366009302','0','0','member','index','login','code|s:4:\"hduc\";');");

require("../../inc/footer.php");
?>