<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_sso_members`;");
E_C("CREATE TABLE `lt_sso_members` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `random` char(8) NOT NULL DEFAULT '',
  `email` char(32) NOT NULL DEFAULT '',
  `regip` char(15) NOT NULL DEFAULT '',
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `lastip` char(15) NOT NULL DEFAULT '0',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `appname` char(15) NOT NULL,
  `type` enum('app','connect') DEFAULT NULL,
  `avatar` tinyint(1) NOT NULL DEFAULT '0',
  `ucuserid` mediumint(8) unsigned DEFAULT '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `ucuserid` (`ucuserid`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8");
E_D("replace into `lt_sso_members` values('1','susu','42ad58922558e6c0ae463d114918972c','qqyE8s','1066234672@qq.com','127.0.0.1','1364354335','121.197.90.163','1365475919','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('2','qaz123','5501c233703668055f86c2eb0f0ce4c9','Ewg5g8','624245068@qq.com','127.0.0.1','1364365827','121.197.90.163','1366009303','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('3','123qaz','11546b4671f10df3eb5bd7b759761a50','XRXKH6','1066234673@qq.com','127.0.0.1','1364438036','121.197.90.163','1365563337','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('4','aaa','a574a3828f3f0a8152da4340c0270ab1','idafJw','1066234671@qq.com','127.0.0.1','1364438422','121.197.90.163','1365558161','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('5','zhf','4f456e695e3958eaa1c398b5ba1e2a21','Daiy6D','1066234674@qq.com','127.0.0.1','1364438932','0','1364438932','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('6','syr','965fbfcc66acd942589452aaa73c2073','pnEQsR','1066234675@qq.com','127.0.0.1','1364439085','121.197.90.163','1365558006','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('7','xueqiang','62eb57b63f7262387011e9ba2ecadcca','nXCXPW','xueqiang123_0@163.com','202.204.107.4','1365322729','0','1365322729','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('8','yyx','1309d2684bc943841eca6dc65566cc74','cUmEwc','123@163.com','202.204.107.4','1365323191','121.197.90.163','1365484420','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('9','zhf123','299c0df1e926f10f088df0f3f8b86946','rA7zFh','624245069@qq.com','61.149.195.46','1365386194','121.197.90.163','1365557944','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('10','zyn123','5ba0d8a4e4679da81afb3398973fc9ea','rEwmv7','zyn@wz010.net','61.149.195.46','1365388612','121.197.90.163','1366008339','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('15','susu111','b37f853ee8c6c2610505ad4156ff2619','N2QCCF','624245065@qq.com','61.149.194.81','1365496951','121.197.90.163','1365670400','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('16','DKSH','362db02b42eba4d9fa1eba4438596f4d','j1rmIf','456@163.com','222.129.42.9','1365568528','0','1365568528','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('17','EXEN','ff3e8c0da44f83362bcb0952d531c397','CcSuLq','789@163.com','222.129.42.9','1365569232','0','1365569232','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('18','111','e70eda89072bc29a43eef436d626fef0','uqw2Lu','1111111@163.com','114.250.207.92','1365582804','121.197.90.163','1365994708','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('19','111111','9469eb870c3ed57e888a677270eff6c5','Td2mj9','11111111111@163.com','114.250.207.92','1365594116','0','1365594116','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('20','luguo','c186cbd1e225dcc1ff17495d97abbb5b','lwd23Q','luguo@sina.com','222.129.36.111','1365670739','0','1365670739','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('21','222','c9267acc98760e6f9408a2c5d9885167','G1zKuT','222222@163.com','111.193.244.232','1365994810','0','1365994810','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('22','333','8f395550e93322cb6bf461cb9704292c','IxBRLi','333333@163.com','111.193.244.232','1366006238','0','1366006238','phpcms v9','app','0','0');");
E_D("replace into `lt_sso_members` values('23','444','c289269b487284c256c406d4ec3dc429','gyI6aq','444444@163.com','111.193.244.232','1366006651','0','1366006651','phpcms v9','app','0','0');");

require("../../inc/footer.php");
?>