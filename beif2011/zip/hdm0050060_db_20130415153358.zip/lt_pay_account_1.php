<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_pay_account`;");
E_C("CREATE TABLE `lt_pay_account` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `trade_sn` char(50) NOT NULL,
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `contactname` char(50) NOT NULL,
  `email` char(40) NOT NULL,
  `telephone` char(20) NOT NULL,
  `discount` float(8,2) NOT NULL DEFAULT '0.00',
  `money` char(8) NOT NULL,
  `quantity` int(8) unsigned NOT NULL DEFAULT '1',
  `addtime` int(10) NOT NULL DEFAULT '0',
  `paytime` int(10) NOT NULL DEFAULT '0',
  `usernote` char(255) NOT NULL,
  `pay_id` tinyint(3) NOT NULL,
  `pay_type` enum('offline','recharge','selfincome','online') NOT NULL DEFAULT 'recharge',
  `payment` char(90) NOT NULL,
  `type` tinyint(3) NOT NULL DEFAULT '1',
  `ip` char(15) NOT NULL DEFAULT '0.0.0.0',
  `status` enum('succ','failed','error','progress','timeout','cancel','waitting','unpay') NOT NULL DEFAULT 'unpay',
  `adminnote` char(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `userid` (`userid`),
  KEY `trade_sn` (`trade_sn`,`money`,`status`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `lt_pay_account` values('1','27_264','3','123qaz','','','','0.00','1','1','1365403143','0','','0','selfincome','投稿奖励','2','61.149.195.46','succ','');");
E_D("replace into `lt_pay_account` values('2','27_317','2','qaz123','','','','0.00','1','1','1365668342','0','','0','selfincome','投稿奖励','2','222.129.36.111','succ','');");
E_D("replace into `lt_pay_account` values('3','37_369','22','333','','','','0.00','1','1','1366006451','0','','0','selfincome','投稿奖励','2','111.193.244.232','succ','');");
E_D("replace into `lt_pay_account` values('4','37_370','22','333','','','','0.00','1','1','1366006462','0','','0','selfincome','投稿奖励','2','111.193.244.232','succ','');");
E_D("replace into `lt_pay_account` values('5','37_371','22','333','','','','0.00','1','1','1366006474','0','','0','selfincome','投稿奖励','2','111.193.244.232','succ','');");

require("../../inc/footer.php");
?>