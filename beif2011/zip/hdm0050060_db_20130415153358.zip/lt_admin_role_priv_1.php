<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_admin_role_priv`;");
E_C("CREATE TABLE `lt_admin_role_priv` (
  `roleid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `m` char(20) NOT NULL,
  `c` char(20) NOT NULL,
  `a` char(20) NOT NULL,
  `data` char(30) NOT NULL DEFAULT '',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  KEY `roleid` (`roleid`,`m`,`c`,`a`,`siteid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lt_admin_role_priv` values('2','content','content','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','pass','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','push','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','move','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','add_othors','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','delete','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','create_html','batch_show','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content','listorder','','1');");
E_D("replace into `lt_admin_role_priv` values('2','attachment','manage','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','attachment','manage','dir','','1');");
E_D("replace into `lt_admin_role_priv` values('2','attachment','manage','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','attachment','address','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','attachment','address','update','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','elite','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','delete','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','listorder','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','content','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','content','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','content','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','content','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','content','delete','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','content','listorder','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','import','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','html','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','special','create_special_list','','1');");
E_D("replace into `lt_admin_role_priv` values('2','special','album','import','','1');");
E_D("replace into `lt_admin_role_priv` values('2','block','block_admin','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','block','block_admin','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','block','block_admin','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','block','block_admin','del','','1');");
E_D("replace into `lt_admin_role_priv` values('2','block','block_admin','block_update','','1');");
E_D("replace into `lt_admin_role_priv` values('2','block','block_admin','history_restore','','1');");
E_D("replace into `lt_admin_role_priv` values('2','block','block_admin','history_del','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','manage','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','del','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','col_url_list','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','publist','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','node_import','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','export','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','col_content','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','import','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','copy','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','content_del','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','import_program_add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','import_program_del','','1');");
E_D("replace into `lt_admin_role_priv` values('2','collection','node','import_content','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','delete','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','setting','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','subscribe_list','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','sub_del','','1');");
E_D("replace into `lt_admin_role_priv` values('2','video','video','import_ku6video','','1');");
E_D("replace into `lt_admin_role_priv` values('2','release','html','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','release','index','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','release','index','failed','','1');");
E_D("replace into `lt_admin_role_priv` values('2','release','index','del','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','create_html','show','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','create_html','update_urls','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','create_html','category','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','create_html','public_index','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','content_settings','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','position','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','position','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','position','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','init','module=admin','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','add','s=0','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','public_cache','module=admin','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','add','s=1','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','add','s=2','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','count_items','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','category','batch_edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel','import','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel_field','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel','disabled','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel','delete','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','sitemodel','export','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','type_manage','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','type_manage','add','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','type_manage','delete','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','type_manage','edit','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','index','public_main','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','admin_manage','init','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','admin_manage','public_edit_pwd','','1');");
E_D("replace into `lt_admin_role_priv` values('2','admin','admin_manage','public_edit_info','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','create_html_opt','index','','1');");
E_D("replace into `lt_admin_role_priv` values('2','content','create_html','public_index','','1');");

require("../../inc/footer.php");
?>