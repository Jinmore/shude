<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_member_qyhy`;");
E_C("CREATE TABLE `lt_member_qyhy` (
  `userid` mediumint(8) unsigned NOT NULL,
  `xingb` varchar(255) NOT NULL DEFAULT '男',
  `dwmc` varchar(255) NOT NULL DEFAULT '',
  `gjcs` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) NOT NULL DEFAULT '',
  `tel` varchar(255) NOT NULL DEFAULT '',
  `zuoj` varchar(255) NOT NULL DEFAULT '',
  `fax` varchar(255) NOT NULL DEFAULT '',
  `site` varchar(255) NOT NULL DEFAULT '',
  `zhiw` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lt_member_qyhy` values('15','男','龙鼎腾信','中国','北京市海淀区西三旗','100193','15801035399','','','','程序员');");
E_D("replace into `lt_member_qyhy` values('2','男','龙鼎腾信','中国','北京市海淀区西三旗','100193','15801035399','','','','程序员');");
E_D("replace into `lt_member_qyhy` values('1','男','龙鼎腾信','中国','北京市海淀区知春路56号中国天利','100193','1231231231','51879256','','','程序员');");
E_D("replace into `lt_member_qyhy` values('10','男','龙鼎腾信','中国','北京市海淀区西三旗','100193','1341312311','','','','主管');");
E_D("replace into `lt_member_qyhy` values('9','男','龙鼎腾信','中国','北京市海淀区西三旗','100193','1231231231','','','','程序员');");
E_D("replace into `lt_member_qyhy` values('8','男','龙鼎腾信','中国','北京市海淀区西三旗','100193','15801035399','51879256','','','主管');");
E_D("replace into `lt_member_qyhy` values('6','男','龙鼎腾信','中国','北京市海淀区西三旗','100193','15801035399','51879256','','','设计师');");
E_D("replace into `lt_member_qyhy` values('4','男','美国贝克曼库尔特商贸（中国）有限公司','广州','广州市天河区林和中路8号天誉大厦22楼02-04单元 ','510610','1','020-8518 7188','020-8518 7188','','经理');");
E_D("replace into `lt_member_qyhy` values('3','男','道奇威(成都)科技有限公司','成都','成都市实业街59号新世界商务楼12楼 ','610015 ','1','028-82600223、87750872、87750620 ','','','经理');");
E_D("replace into `lt_member_qyhy` values('16','女','大昌华嘉商业（中国）有限公司','上海市虹梅路1801号凯科国际大厦2208室 ','上海市虹梅路1801号凯科国际大厦2208室 ','200233 ','400-821-0778 ','021-33678466 ','021-33678466 ','','经理');");
E_D("replace into `lt_member_qyhy` values('17','男','爱科昇振动机械（嘉兴）有限公司','浙江','浙江省嘉兴市南湖区余新镇镇北路22号 ','314009 ','1','0573-83162015 ','0573-83162015 ','','经理');");
E_D("replace into `lt_member_qyhy` values('19','男','1111111111','111111111111','11111111111111','111111','','','','','');");
E_D("replace into `lt_member_qyhy` values('20','女','龙鼎腾信','中国','北京市海淀区西三旗','100193','','','','','程序员');");
E_D("replace into `lt_member_qyhy` values('21','男','222222','222222','222222','222222','','','','','');");
E_D("replace into `lt_member_qyhy` values('23','男','444444','444444','444444','444444','444444','444444','444444','444444','444444');");

require("../../inc/footer.php");
?>