<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_yp_relation`;");
E_C("CREATE TABLE `lt_yp_relation` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `catid` mediumint(8) unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lt_yp_relation` values('2','98');");
E_D("replace into `lt_yp_relation` values('1','97');");
E_D("replace into `lt_yp_relation` values('8','98');");
E_D("replace into `lt_yp_relation` values('9','95');");
E_D("replace into `lt_yp_relation` values('10','95');");
E_D("replace into `lt_yp_relation` values('6','97');");
E_D("replace into `lt_yp_relation` values('15','98');");
E_D("replace into `lt_yp_relation` values('4','98');");
E_D("replace into `lt_yp_relation` values('3','97');");
E_D("replace into `lt_yp_relation` values('16','98');");
E_D("replace into `lt_yp_relation` values('17','98');");
E_D("replace into `lt_yp_relation` values('19','97');");
E_D("replace into `lt_yp_relation` values('20','95');");
E_D("replace into `lt_yp_relation` values('23','95');");

require("../../inc/footer.php");
?>