<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_mobile_setting`;");
E_C("CREATE TABLE `bbs_mobile_setting` (
  `skey` varchar(255) NOT NULL DEFAULT '',
  `svalue` text NOT NULL,
  PRIMARY KEY (`skey`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `bbs_mobile_setting` values('extend_used','1');");
E_D("replace into `bbs_mobile_setting` values('extend_lastupdate','1343182299');");

require("../../inc/footer.php");
?>