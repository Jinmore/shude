<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_content_check`;");
E_C("CREATE TABLE `lt_content_check` (
  `checkid` char(15) NOT NULL,
  `catid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `title` char(80) NOT NULL,
  `username` char(20) NOT NULL,
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  KEY `username` (`username`),
  KEY `checkid` (`checkid`),
  KEY `status` (`status`,`inputtime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lt_content_check` values('c-264-1','27','1','图片资料下载','123qaz','1365403143','99');");
E_D("replace into `lt_content_check` values('c-317-1','27','1','会员投稿','qaz123','1365668342','99');");
E_D("replace into `lt_content_check` values('c-369-1','37','1','调试','333','1366006451','99');");
E_D("replace into `lt_content_check` values('c-370-1','37','1','调试','333','1366006462','99');");
E_D("replace into `lt_content_check` values('c-371-1','37','1','调试','333','1366006474','99');");

require("../../inc/footer.php");
?>