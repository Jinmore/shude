<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_poster_201303`;");
E_C("CREATE TABLE `lt_poster_201303` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `spaceid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `username` char(20) NOT NULL,
  `area` char(40) NOT NULL,
  `ip` char(15) NOT NULL,
  `referer` char(120) NOT NULL,
  `clicktime` int(10) unsigned NOT NULL DEFAULT '0',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`,`type`,`ip`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8");
E_D("replace into `lt_poster_201303` values('1','3','1','0','','LAN','127.0.0.1','http://hmu178163.chinaw3.com/index.php?m=poster&c=space&a=public_preview&spaceid=11&pc_hash=7deNTN','1363829151','1');");
E_D("replace into `lt_poster_201303` values('2','9','1','0','','LAN','127.0.0.1','http://hmu178163.chinaw3.com/','1363831251','1');");
E_D("replace into `lt_poster_201303` values('3','22','1','0','','LAN','127.0.0.1','http://hmu178163.chinaw3.com/','1364175652','1');");
E_D("replace into `lt_poster_201303` values('4','37','1','0','','LAN','127.0.0.1','http://hmu178163.chinaw3.com/index.php?m=content&c=index&a=lists&catid=1','1364268010','1');");

require("../../inc/footer.php");
?>