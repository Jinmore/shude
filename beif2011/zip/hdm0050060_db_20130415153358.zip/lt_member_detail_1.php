<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_member_detail`;");
E_C("CREATE TABLE `lt_member_detail` (
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `sex` varchar(255) NOT NULL DEFAULT '男',
  `dwmc` varchar(255) NOT NULL DEFAULT '',
  `hymc` varchar(255) NOT NULL DEFAULT '',
  `gjcs` varchar(255) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `zip` varchar(255) NOT NULL DEFAULT '',
  `tel` varchar(255) NOT NULL DEFAULT '',
  `zuoj` varchar(255) NOT NULL DEFAULT '',
  `fax` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `userid` (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `lt_member_detail` values('1','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('2','女','龙鼎腾信','计算机','中国','北京市海淀区西三旗','1001093','15801035399','51879256','55784562');");
E_D("replace into `lt_member_detail` values('3','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('4','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('5','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('6','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('7','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('8','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('9','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('10','男','','','','','','','','');");
E_D("replace into `lt_member_detail` values('18','男','1','1','1','1','1','1','','');");
E_D("replace into `lt_member_detail` values('22','男','333333','333333','333333','333333','333333','333333','333333','333333');");

require("../../inc/footer.php");
?>