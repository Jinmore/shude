<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_member`;");
E_C("CREATE TABLE `lt_member` (
  `userid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `phpssouid` mediumint(8) unsigned NOT NULL,
  `username` char(20) NOT NULL DEFAULT '',
  `password` char(32) NOT NULL DEFAULT '',
  `encrypt` char(6) NOT NULL,
  `nickname` char(20) NOT NULL,
  `regdate` int(10) unsigned NOT NULL DEFAULT '0',
  `lastdate` int(10) unsigned NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL DEFAULT '',
  `lastip` char(15) NOT NULL DEFAULT '',
  `loginnum` smallint(5) unsigned NOT NULL DEFAULT '0',
  `email` char(32) NOT NULL DEFAULT '',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `areaid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `amount` decimal(8,2) unsigned NOT NULL DEFAULT '0.00',
  `point` smallint(5) unsigned NOT NULL DEFAULT '0',
  `modelid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `message` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `islock` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `vip` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `overduedate` int(10) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '1',
  `connectid` char(15) NOT NULL DEFAULT '',
  `from` char(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`userid`),
  UNIQUE KEY `username` (`username`),
  KEY `email` (`email`(20)),
  KEY `phpssouid` (`phpssouid`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8");
E_D("replace into `lt_member` values('1','1','susu','42ad58922558e6c0ae463d114918972c','qqyE8s','苏苏','1364354335','1365475918','127.0.0.1','61.149.194.81','0','1066234672@qq.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('2','2','qaz123','5501c233703668055f86c2eb0f0ce4c9','Ewg5g8','苏颜冉','1364365827','1366009302','127.0.0.1','61.149.197.36','0','624245068@qq.com','2','0','0.00','65535','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('3','3','123qaz','11546b4671f10df3eb5bd7b759761a50','XRXKH6','qaz','1364438036','1365563336','127.0.0.1','222.129.42.9','0','1066234673@qq.com','2','0','0.00','1','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('4','4','aaa','a574a3828f3f0a8152da4340c0270ab1','idafJw','aaa','1364438422','1365558160','127.0.0.1','222.129.42.9','0','1066234671@qq.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('5','5','zhf','4f456e695e3958eaa1c398b5ba1e2a21','Daiy6D','zhf','1364438932','1364438932','127.0.0.1','','0','1066234674@qq.com','2','0','0.00','0','10','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('6','6','syr','965fbfcc66acd942589452aaa73c2073','pnEQsR','syz','1364439085','1365558005','127.0.0.1','222.129.42.9','0','1066234675@qq.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('7','7','xueqiang','62eb57b63f7262387011e9ba2ecadcca','nXCXPW','smalljump','1365322727','1365322727','202.204.107.4','','0','xueqiang123_0@163.com','2','0','0.00','0','10','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('8','8','yyx','1309d2684bc943841eca6dc65566cc74','cUmEwc','123','1365323190','1365484419','202.204.107.4','61.149.194.81','0','123@163.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('9','9','zhf123','299c0df1e926f10f088df0f3f8b86946','rA7zFh','赵洪菲','1365386193','1365557943','61.149.195.46','222.129.42.9','0','624245069@qq.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('10','10','zyn123','5ba0d8a4e4679da81afb3398973fc9ea','rEwmv7','qq','1365388611','1366008338','61.149.195.46','61.149.197.36','0','zyn@wz010.net','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('15','15','susu111','b37f853ee8c6c2610505ad4156ff2619','N2QCCF','苏苏111','1365496950','1365670399','61.149.194.81','222.129.36.111','0','624245065@qq.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('16','16','DKSH','362db02b42eba4d9fa1eba4438596f4d','j1rmIf','胡小姐','1365568527','1365568527','222.129.42.9','','0','456@163.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('17','17','EXEN','ff3e8c0da44f83362bcb0952d531c397','CcSuLq','舒升兴','1365569231','1365569231','222.129.42.9','','0','789@163.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('18','18','111','e70eda89072bc29a43eef436d626fef0','uqw2Lu','xueqiang','1365582803','1365994707','114.250.207.92','111.193.244.232','0','1111111@163.com','2','0','0.00','0','10','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('19','19','111111','9469eb870c3ed57e888a677270eff6c5','Td2mj9','11111','1365594115','1365594115','114.250.207.92','','0','11111111111@163.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('20','20','luguo','c186cbd1e225dcc1ff17495d97abbb5b','lwd23Q','赵洪菲','1365670738','1365670738','222.129.36.111','','0','luguo@sina.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('21','21','222','c9267acc98760e6f9408a2c5d9885167','G1zKuT','xueqiang','1365994809','1365994809','111.193.244.232','','0','222222@163.com','2','0','0.00','0','17','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('22','22','333','8f395550e93322cb6bf461cb9704292c','IxBRLi','333333','1366006237','1366006237','111.193.244.232','','0','333333@163.com','2','0','0.00','3','10','0','0','0','0','1','','');");
E_D("replace into `lt_member` values('23','23','444','c289269b487284c256c406d4ec3dc429','gyI6aq','444444','1366006650','1366006650','111.193.244.232','','0','444444@163.com','2','0','0.00','0','17','0','0','0','0','1','','');");

require("../../inc/footer.php");
?>