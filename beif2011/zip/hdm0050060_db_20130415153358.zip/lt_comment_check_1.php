<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_comment_check`;");
E_C("CREATE TABLE `lt_comment_check` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `comment_data_id` int(10) DEFAULT '0' COMMENT '论评ID号',
  `siteid` smallint(5) NOT NULL DEFAULT '0' COMMENT '站点ID',
  `tableid` mediumint(8) DEFAULT '0' COMMENT '数据存储表ID',
  PRIMARY KEY (`id`),
  KEY `siteid` (`siteid`),
  KEY `comment_data_id` (`comment_data_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `lt_comment_check` values('1','1','1','1');");
E_D("replace into `lt_comment_check` values('2','2','1','1');");
E_D("replace into `lt_comment_check` values('3','3','1','1');");
E_D("replace into `lt_comment_check` values('4','4','1','1');");
E_D("replace into `lt_comment_check` values('5','5','1','1');");

require("../../inc/footer.php");
?>