<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_position`;");
E_C("CREATE TABLE `lt_position` (
  `posid` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `modelid` smallint(5) unsigned DEFAULT '0',
  `catid` smallint(5) unsigned DEFAULT '0',
  `name` char(30) NOT NULL DEFAULT '',
  `maxnum` smallint(5) NOT NULL DEFAULT '20',
  `extention` char(100) DEFAULT NULL,
  `listorder` smallint(5) unsigned NOT NULL DEFAULT '0',
  `siteid` smallint(5) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`posid`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8");
E_D("replace into `lt_position` values('2','0','0','首页焦点图推荐','5','','0','0');");
E_D("replace into `lt_position` values('3','0','0','首页头条推荐','5','','0','0');");
E_D("replace into `lt_position` values('4','0','0','首页新闻列表推荐','20','10','0','0');");
E_D("replace into `lt_position` values('5','1','1','新闻焦点图推荐','5','','0','1');");
E_D("replace into `lt_position` values('6','1','2','技术焦点图推荐','5','','0','1');");
E_D("replace into `lt_position` values('7','1','2','技术列表推荐','10','','0','1');");
E_D("replace into `lt_position` values('8','1','3','市场列表推荐','10','','0','1');");
E_D("replace into `lt_position` values('9','1','3','市场焦点图推荐','5','','0','1');");
E_D("replace into `lt_position` values('10','1','40','矿物粉体专栏推荐','1','','0','1');");

require("../../inc/footer.php");
?>