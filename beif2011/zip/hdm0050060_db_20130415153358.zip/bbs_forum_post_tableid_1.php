<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_forum_post_tableid`;");
E_C("CREATE TABLE `bbs_forum_post_tableid` (
  `pid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`pid`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8");
E_D("replace into `bbs_forum_post_tableid` values('1');");
E_D("replace into `bbs_forum_post_tableid` values('2');");
E_D("replace into `bbs_forum_post_tableid` values('3');");
E_D("replace into `bbs_forum_post_tableid` values('4');");
E_D("replace into `bbs_forum_post_tableid` values('5');");

require("../../inc/footer.php");
?>