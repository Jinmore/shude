<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `lt_yp_product`;");
E_C("CREATE TABLE `lt_yp_product` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `catid` int(10) unsigned NOT NULL DEFAULT '0',
  `typeid` smallint(5) unsigned NOT NULL,
  `title` varchar(80) NOT NULL DEFAULT '',
  `style` char(24) NOT NULL DEFAULT '',
  `thumb` char(100) NOT NULL DEFAULT '',
  `keywords` char(40) NOT NULL DEFAULT '',
  `description` char(255) NOT NULL DEFAULT '',
  `posids` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `url` char(100) NOT NULL,
  `listorder` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(2) unsigned NOT NULL DEFAULT '1',
  `sysadd` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `userid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `username` varchar(20) NOT NULL DEFAULT '',
  `inputtime` int(10) unsigned NOT NULL DEFAULT '0',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0',
  `elite` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `areaid` int(10) unsigned NOT NULL DEFAULT '0',
  `price` float unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `status` (`status`,`listorder`,`id`),
  KEY `listorder` (`catid`,`status`,`listorder`,`id`),
  KEY `catid` (`catid`,`status`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8");
E_D("replace into `lt_yp_product` values('3','258','0','产品名称一','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327050848318.jpg','产品名称 一','产品名称一','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=258&id=3','0','99','0','2','qaz123','1364446708','1364548484','1','0','0');");
E_D("replace into `lt_yp_product` values('2','217','0','粉体产品','','','丹东 百特 举行','丹东百特举行2012年粒度测试技术（广州）交流会','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=217&id=2','0','99','0','1','susu','1364361536','1364548496','0','0','0');");
E_D("replace into `lt_yp_product` values('4','288','0','助剂产品名称一','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327051528221.jpg','助剂 产品名称 一','助剂产品名称一','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=288&id=4','0','99','0','2','qaz123','1364451844','1364548465','1','0','0');");
E_D("replace into `lt_yp_product` values('5','297','0','设备产品名称一','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327051528221.jpg','设备 产品名称 一','设备产品名称一','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=297&id=5','0','99','0','2','qaz123','1364446667','1364806032','1','0','0');");
E_D("replace into `lt_yp_product` values('6','308','0','设备产品名称二','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327050848318.jpg','设备 产品名称 二','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=308&id=6','0','99','0','2','qaz123','1364446654','1364548433','1','0','0');");
E_D("replace into `lt_yp_product` values('7','308','0','设备产品名称三','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327051451766.jpg','设备 产品名称 三','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=308&id=7','0','99','0','2','qaz123','1364436600','1364548420','1','0','0');");
E_D("replace into `lt_yp_product` values('8','268','0','助剂产品名称二','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327050848318.jpg','助剂 产品名称 二','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=268&id=8','0','99','0','2','qaz123','1364436614','1364806027','1','0','0');");
E_D("replace into `lt_yp_product` values('9','272','0','助剂产品名称三','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327050848318.jpg','助剂 产品名称 三','助剂产品名称三','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=272&id=9','0','99','0','2','qaz123','1364446639','1364548391','1','0','0');");
E_D("replace into `lt_yp_product` values('10','272','0','助剂产品名称一','','http://hmu178163.chinaw3.com/uploadfile/2013/0327/20130327051451766.jpg','粉体 产品名称 一','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=272&id=10','0','99','0','2','qaz123','1364452310','1364548375','1','0','0');");
E_D("replace into `lt_yp_product` values('11','297','0','设备产品四','','http://hmu178163.chinaw3.com/uploadfile/2013/0328/20130328020241484.jpg','设备 产品 四','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=297&id=11','0','99','0','2','qaz123','1364451258','1364806021','1','0','0');");
E_D("replace into `lt_yp_product` values('24','356','0','N-A型高浓度粉体压送机 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410093055456.jpg','N-A 型 高浓度','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=356&id=24','0','99','0','15','susu111','1365557513','1365557513','1','0','0');");
E_D("replace into `lt_yp_product` values('12','302','0','MYM型卧式砂磨机','','http://hmu178163.chinaw3.com/uploadfile/2013/0408/20130408111909213.jpg','MYM 型 卧式','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=302&id=12','0','99','0','10','zyn123','1365391243','1365391522','1','0','0');");
E_D("replace into `lt_yp_product` values('13','302','0','新一代高精度微米分级机','','http://hmu178163.chinaw3.com/uploadfile/2013/0408/20130408112510896.jpg','新一代 高精度 微米','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=302&id=13','0','99','0','10','zyn123','1365391791','1365391791','1','0','0');");
E_D("replace into `lt_yp_product` values('14','299','0','QYF型流化床气流粉碎机','','http://hmu178163.chinaw3.com/uploadfile/2013/0408/20130408113429114.jpg','QYF 型 流化床','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=299&id=14','0','99','0','10','zyn123','1365392101','1365392101','1','0','0');");
E_D("replace into `lt_yp_product` values('15','301','0','WFJ型微米分级机','','http://hmu178163.chinaw3.com/uploadfile/2013/0408/20130408125705336.jpg','WFJ 型 微米','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=301&id=15','0','99','0','10','zyn123','1365397423','1365397423','1','0','0');");
E_D("replace into `lt_yp_product` values('17','205','0','供应改性氢氧化镁','','http://hmu178163.chinaw3.com/uploadfile/2013/0408/20130408053233953.jpg','供应 改性 氢','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=205&id=17','0','99','0','10','zyn123','1365413578','1365413578','1','0','0');");
E_D("replace into `lt_yp_product` values('18','197','0','供应重质碳酸钙 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0409/20130409093900487.jpg','供应 重 质碳酸钙','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=197&id=18','0','99','0','10','zyn123','1365471566','1365471566','1','0','0');");
E_D("replace into `lt_yp_product` values('19','193','0','超白煅烧高岭土 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0409/20130409094153581.jpg','超 白 煅烧','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=193&id=19','0','99','0','10','zyn123','1365471736','1365471736','1','0','0');");
E_D("replace into `lt_yp_product` values('20','179','0','绢云母粉','','http://hmu178163.chinaw3.com/uploadfile/2013/0409/20130409094413692.jpg','绢 云母粉','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=179&id=20','0','99','0','10','zyn123','1365471875','1365471875','1','0','0');");
E_D("replace into `lt_yp_product` values('21','203','0','高光钡 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0409/20130409094605991.jpg','高 光 钡','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=203&id=21','0','99','0','10','zyn123','1365471979','1365471979','1','0','0');");
E_D("replace into `lt_yp_product` values('22','203','0','重晶石粉 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0409/20130409094720646.jpg','重晶石 粉','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=203&id=22','0','99','0','10','zyn123','1365472059','1365472059','1','0','0');");
E_D("replace into `lt_yp_product` values('23','178','0','硅微粉 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0409/20130409094909656.jpg','硅微粉','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=178&id=23','0','99','0','10','zyn123','1365472165','1365472165','1','0','0');");
E_D("replace into `lt_yp_product` values('25','305','0','库尔特颗粒计数仪（Coulter Counter） ','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410100250995.jpg','库尔特 颗粒 计数','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=305&id=25','0','99','0','4','aaa','1365559404','1365559404','1','0','0');");
E_D("replace into `lt_yp_product` values('26','305','0','库尔特激光粒度分析仪','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410100440992.jpg','库尔特 激光 粒度','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=305&id=26','0','99','0','4','aaa','1365559510','1365559510','1','0','0');");
E_D("replace into `lt_yp_product` values('27','305','0','高浓度Zeta电位仪 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410101803910.jpg','高浓度 Zeta 电位','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=305&id=27','0','99','0','4','aaa','1365560314','1365560314','1','0','0');");
E_D("replace into `lt_yp_product` values('28','305','0','细胞计数分析仪','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410101955892.jpg','细胞 计数 分析仪','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=305&id=28','0','99','0','4','aaa','1365560438','1365560438','1','0','0');");
E_D("replace into `lt_yp_product` values('29','308','0','颗粒形态及粒度（图像）分析仪 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410102317312.jpg','颗粒 形态 粒度','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=308&id=29','0','99','0','4','aaa','1365560626','1365560626','1','0','0');");
E_D("replace into `lt_yp_product` values('30','305','0','S3500SI图像激光粒度分析仪 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410124158629.jpg','S3500SI 图像 激光','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=305&id=30','0','99','0','16','DKSH','1365568949','1365568949','1','0','0');");
E_D("replace into `lt_yp_product` values('31','305','0','美国麦奇克激光粒度仪 ','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410124331411.jpg','美国 麦奇克 激光','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=305&id=31','0','99','0','16','DKSH','1365569037','1365569037','1','0','0');");
E_D("replace into `lt_yp_product` values('32','350','0','UP塑料球形振动器','','http://hmu178163.chinaw3.com/uploadfile/2013/0410/20130410125431482.jpg','UP 塑料 球形','','0','http://hmu178163.chinaw3.com/index.php?m=yp&c=index&a=show&catid=350&id=32','0','99','0','17','EXEN','1365569702','1365569702','1','0','0');");

require("../../inc/footer.php");
?>