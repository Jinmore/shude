<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_common_plugin`;");
E_C("CREATE TABLE `bbs_common_plugin` (
  `pluginid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `available` tinyint(1) NOT NULL DEFAULT '0',
  `adminid` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `name` varchar(40) NOT NULL DEFAULT '',
  `identifier` varchar(40) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `datatables` varchar(255) NOT NULL DEFAULT '',
  `directory` varchar(100) NOT NULL DEFAULT '',
  `copyright` varchar(100) NOT NULL DEFAULT '',
  `modules` text NOT NULL,
  `version` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`pluginid`),
  UNIQUE KEY `identifier` (`identifier`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8");
E_D("replace into `bbs_common_plugin` values('1','0','1','QQ互联','qqconnect','','','qqconnect/','Comsenz Inc.','a:6:{i:0;a:10:{s:4:\"name\";s:7:\"connect\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:1;a:10:{s:4:\"name\";s:7:\"spacecp\";s:4:\"menu\";s:8:\"QQ绑定\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:1:\"7\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"1\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:2;a:10:{s:4:\"name\";s:6:\"qqshow\";s:4:\"menu\";s:5:\"QQ秀\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:1:\"7\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"2\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:3;a:10:{s:4:\"name\";s:7:\"connect\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"28\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:2:{s:11:\"installtype\";s:0:\"\";s:10:\"langexists\";i:1;}}','1.17');");
E_D("replace into `bbs_common_plugin` values('2','0','1','腾讯分析','cloudstat','','','cloudstat/','Comsenz Inc.','a:4:{i:0;a:10:{s:4:\"name\";s:9:\"cloudstat\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"28\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:1;a:10:{s:4:\"name\";s:9:\"cloudstat\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:1:{s:11:\"installtype\";s:0:\"\";}}','1.06');");
E_D("replace into `bbs_common_plugin` values('3','0','1','SOSO表情','soso_smilies','','','soso_smilies/','Comsenz Inc.','a:4:{i:0;a:10:{s:4:\"name\";s:4:\"soso\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"28\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:1;a:10:{s:4:\"name\";s:4:\"soso\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:1:{s:11:\"installtype\";s:0:\"\";}}','1.3');");
E_D("replace into `bbs_common_plugin` values('4','0','1','纵横搜索','cloudsearch','','','cloudsearch/','Comsenz Inc.','a:4:{i:0;a:10:{s:4:\"name\";s:6:\"search\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:1;a:10:{s:4:\"name\";s:10:\"search_wap\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"28\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:2:{s:11:\"installtype\";s:0:\"\";s:10:\"langexists\";i:1;}}','1.06');");
E_D("replace into `bbs_common_plugin` values('5','0','1','社区QQ群','qqgroup','','','qqgroup/','Comsenz Inc.','a:3:{i:0;a:10:{s:4:\"name\";s:7:\"qqgroup\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:2:{s:11:\"installtype\";s:0:\"\";s:10:\"langexists\";i:1;}}','1.03');");
E_D("replace into `bbs_common_plugin` values('6','0','1','防水墙','security','','','security/','Comsenz Inc.','a:4:{i:0;a:10:{s:4:\"name\";s:8:\"security\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"28\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"1\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:1;a:10:{s:4:\"name\";s:8:\"security\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"2\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:2:{s:11:\"installtype\";s:0:\"\";s:10:\"langexists\";i:1;}}','1.10');");
E_D("replace into `bbs_common_plugin` values('7','0','1','旋风存储','xf_storage','','','xf_storage/','Comsenz Inc.','a:3:{i:0;a:10:{s:4:\"name\";s:10:\"xf_storage\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:2:{s:11:\"installtype\";s:0:\"\";s:10:\"langexists\";i:1;}}','1.04');");
E_D("replace into `bbs_common_plugin` values('8','1','1','手机客户端','mobile','','','mobile/','Comsenz Inc.','a:4:{i:0;a:10:{s:4:\"name\";s:6:\"mobile\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"28\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}i:1;a:10:{s:4:\"name\";s:6:\"mobile\";s:4:\"menu\";s:0:\"\";s:3:\"url\";s:0:\"\";s:4:\"type\";s:2:\"11\";s:7:\"adminid\";s:1:\"0\";s:12:\"displayorder\";s:1:\"0\";s:8:\"navtitle\";s:0:\"\";s:7:\"navicon\";s:0:\"\";s:10:\"navsubname\";s:0:\"\";s:9:\"navsuburl\";s:0:\"\";}s:6:\"system\";i:2;s:5:\"extra\";a:2:{s:11:\"installtype\";s:0:\"\";s:10:\"langexists\";i:1;}}','1.05');");

require("../../inc/footer.php");
?>