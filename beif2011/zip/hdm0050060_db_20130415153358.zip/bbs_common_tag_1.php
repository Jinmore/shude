<?php
require("../../inc/header.php");

/*
		SoftName : EmpireBak Version 2010
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

DoSetDbChar('utf8');
E_D("DROP TABLE IF EXISTS `bbs_common_tag`;");
E_C("CREATE TABLE `bbs_common_tag` (
  `tagid` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `tagname` char(20) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tagid`),
  KEY `tagname` (`tagname`),
  KEY `status` (`status`,`tagid`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8");
E_D("replace into `bbs_common_tag` values('1','纳米','0');");
E_D("replace into `bbs_common_tag` values('2','药物','0');");
E_D("replace into `bbs_common_tag` values('3','建筑涂料','0');");
E_D("replace into `bbs_common_tag` values('4','的','0');");
E_D("replace into `bbs_common_tag` values('5','非金属','0');");
E_D("replace into `bbs_common_tag` values('6','材料','0');");
E_D("replace into `bbs_common_tag` values('7','国家','0');");
E_D("replace into `bbs_common_tag` values('8','中心','0');");
E_D("replace into `bbs_common_tag` values('9','检测','0');");
E_D("replace into `bbs_common_tag` values('10','癌细胞','0');");
E_D("replace into `bbs_common_tag` values('11','质谱仪','0');");
E_D("replace into `bbs_common_tag` values('12','光学','0');");

require("../../inc/footer.php");
?>